<?php
namespace app\controllers;
use yii\web\controller;
use app\models\Roles;
use app\models\Userr;
use app\models\Investments;


class RolesController extends Controller
{
	public function actionTest()
    {
        /*$user = roles::findOne(1);
    	$name=$user->userr;

        //$dob=$name->dob;

        //echo implode(" ",$name);
        echo $name[0]->username;*/

        
    	
        


    }
    public function actionTest2()
    {
        $user=investments::find()
    ->where(['fund_idfund' => 0])
    ->one();;
        $name=$user->units;
        echo $name;
    }
}


  ?>