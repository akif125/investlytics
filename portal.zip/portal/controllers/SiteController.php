<?php

namespace app\controllers;

use Yii;
use yii\filters\AccessControl;
use yii\web\Controller;
use yii\web\Response;
use yii\filters\VerbFilter;
use app\models\LoginForm;
use app\models\ContactForm;
use app\models\Investments;
use app\models\Roles;
use app\models\Userr;
use app\models\Amc;
use app\models\Fund;
use app\models\Nav;
use app\models\Sentiments;

class SiteController extends Controller
{
    /**
     * @inheritdoc
     */
    public function behaviors()
    {
        return [
            'access' => [
                'class' => AccessControl::className(),
                'only' => ['logout'],
                'rules' => [
                    [
                        'actions' => ['logout'],
                        'allow' => true,
                        'roles' => ['@'],
                    ],
                ],
            ],
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'logout' => ['post'],
                ],
            ],
        ];
    }

    /**
     * @inheritdoc
     */
    public function actions()
    {
        return [
            'error' => [
                'class' => 'yii\web\ErrorAction',
            ],
            'captcha' => [
                'class' => 'yii\captcha\CaptchaAction',
                'fixedVerifyCode' => YII_ENV_TEST ? 'testme' : null,
            ],
        ];
    }

    /**
     * Displays homepage.
     *
     * @return string
     */
    public function actionIndex()
    {
        return $this->render('index');
    }
    
    

    /**
     * Login action.
     *
     * @return Response|string
     */
    public function actionLogin()
    {
        if (!Yii::$app->user->isGuest) {
            return $this->goHome();
        }

        $model = new LoginForm();
        if ($model->load(Yii::$app->request->post()) && $model->login()) {
            return $this->goBack();
        }
        return $this->render('login', [
            'model' => $model,
        ]);
    }

    /**
     * Logout action.
     *
     * @return Response
     */
    public function actionLogout()
    {
        Yii::$app->user->logout();

        return $this->goHome();
    }
    
    public function actionTest()
    {
        
    
    $funds=fund::find()
    ->where(['idfund' => 1])
    ->one();
    $id=$funds->idfund;
    $nav=nav::find()
    ->where(['idfund' => $id])
    ->all();
    
    
    }

    /**
     * Displays contact page.
     *
     * @return Response|string
     */
    public function actionContact()
    {
        $model = new ContactForm();
        if ($model->load(Yii::$app->request->post()) && $model->contact(Yii::$app->params['adminEmail'])) {
            Yii::$app->session->setFlash('contactFormSubmitted');

            return $this->refresh();
        }
        return $this->render('contact', [
            'model' => $model,
        ]);
    }

    /**
     * Displays about page.
     *
     * @return string
     */
    public function actionAbout()
    {
        return $this->render('about');
    }
    public function actionUser()
{
    return $this->render('user');
}
public function actionSaveinvestment()
{
    $funds = Yii::$app->request->post('funds');
    $units = Yii::$app->request->post('units');
    $email = Yii::$app->request->post('email');
    
    for ($i=0; $i <sizeof($funds) ; $i++) { 
        $id=fund::find()
    ->where(['name' => $funds[$i]])
    ->one();
    $id_funds[$i]=$id->idfund;
    }
    $user=userr::find()
    ->where(['email' => $email])
    ->one();
    $id_user=$user->iduserr;
    $date=date("Y/m/d");
    for ($i=0; $i <sizeof($funds) ; $i++) { 
        $investments = new Investments();
        $investments->iduserr=$id_user;
        $investments->idfund=$id_funds[$i];
        $investments->units=$units[$i];
        $investments->invested_date=$date;
        $investments->save();

    }
    $test="successfully inserted";
    return \yii\helpers\Json::encode($test);
}
public function actionDemo()
{
    $mContactForm = new \app\models\ContactForm(); 
   $mContactForm->name = "contactForm"; 
   $mContactForm->email = "user@gmail.com"; 
   $mContactForm->subject = "subject"; 
   $mContactForm->body = "body";
   return $this->render('demo',['message' => $mContactForm]);
}
public function actionAdminhome($test=0,$email=0)
{
    // echo $email;
    // echo " ";
    // echo $password;
    $this->layout = 'investorlayout';
    $obj1 = new \app\models\fm1();
    //echo $test;
    $this->view->params['breadcrumbs'] =$email;
    //echo $email;

    $user=amc::find()
    ->where(['name' => $test])
    ->one();
    $id= $user->idamc;
    $funds=fund::find()
    ->where(['idamc' => $id])
    ->all();
   for ($i=0; $i <sizeof($funds) ; $i++) { 
            $obj1->funds[$i]=$funds[$i]->name;
            
            $obj1->Amcs=$test;
            $obj1->email=$email;
   }
    
    


    return $this->render('adminviewamc',['message' => $obj1]);
}
public function actionAdminhome2($test=0)
{
    // echo $email;
    // echo " ";
    // echo $password;
    $this->layout = 'admin_layout';
    $obj1 = new \app\models\fm1();
    //echo $test;
    
    //echo $email;

    $user=amc::find()
    ->where(['name' => $test])
    ->one();
    $id= $user->idamc;
    $funds=fund::find()
    ->where(['idamc' => $id])
    ->all();
   for ($i=0; $i <sizeof($funds) ; $i++) { 
            $obj1->funds[$i]=$funds[$i]->name;
            
            $obj1->Amcs=$test;
           //$obj1->email=$email;
   }

    


    return $this->render('adminviewamc',['message' => $obj1]);
}
public function actionRecomendation($email=0)
{
    $this->layout = 'investorlayout';
    $obj1 = new \app\models\recomdation_model();
    //echo $test;
    $this->view->params['breadcrumbs'] =$email;

    $funds=fund::find()
    ->all();
    for ($i=0; $i <sizeof($funds) ; $i++) { 
        $fund[$i]=$funds[$i]->name;
        $fund_id[$i]=$funds[$i]->idfund;
    }
    for ($i=0; $i <sizeof($fund_id) ; $i++) { 
        # code...
        $nav=nav::find()
    ->where(['idfund' => $fund_id[$i]])
    ->all();
    $nav_last[$i]=$nav[sizeof($nav)-1]->value;
    $nav_second[$i]=$nav[sizeof($nav)-2]->value;
    }
    for ($j=0; $j <(sizeof($nav_last)-1) ; $j++) { 
        # code...
        for ($k=0; $k <(sizeof($nav_last)-1) ; $k++) { 
            if ($nav_last[$k]>$nav_last[$k+1]) {
                $temp=$nav_last[$k];
                $nav_last[$k]=$nav_last[$k+1];
                $nav_last[$k+1]=$temp;



                $temp2=$fund[$k];
                $fund[$k]=$fund[$k+1];
                $fund[$k+1]=$temp2;

                $temp3=$nav_second[$k];
                $nav_second[$k]=$nav_second[$k+1];
                $nav_second[$k+1]=$temp3;
            }
        }
    }

   for ($i=0; $i <sizeof($nav_last) ; $i++) { 
       # code...
        $obj1->funds[$i]=$fund[$i];
        $obj1->nav[$i]=$nav_last[$i];
        $obj1->nav_actual[$i]=$nav_second[$i];
   }



    
    




    return $this->render('recomendation',['obj' => $obj1]);
}
public function actionAdminviewamc()
{
    // echo $email;
    // echo " ";
    // echo $password;
   
    $obj = new \app\models\fm1();
    $obj->Amcs[0] ="NIT";
    $obj->Amcs[1] ="meezzan";
    $obj->Amcs[2] ="HBL";
    $obj->Amcs[3] ="nafa";
    $obj->Amcs[4] ="UBL";
    


    return $this->render('adminviewamc',['message' => $obj]);
}
public function actionDetailsamc()
{

        $obj1 = new \app\models\amc1();
        $test = Yii::$app->request->post('name');
        
        if ($test=="NIT") {
            $obj1->funds[0]="NIUT";
            $obj1->funds[1]="NIUTEQ";
            $obj1->funds[2]="NIT GTF";
        }
        if ($test=="Meezan") {
           $obj1->funds[0]="MIF(Meezan islamic fund)";
           $obj1->funds[1]="MCF(Meezan cash fund)";
           $obj1->funds[2]="MBF(Meezan balanced fund)"; 
        }
        if ($test=="HBL") {
            $obj1->funds[0]="HBL equity fund";
            $obj1->funds[1]="HBL cash fund";
            $obj1->funds[2]="HBL money market fund";
        }
        
    

    // return Json    
    return \yii\helpers\Json::encode($obj1);
    
}
public function actionLogin2()
{
    $email = Yii::$app->request->post('email');
    $password = Yii::$app->request->post('password');
    $test="error";

    $user=userr::find()
    ->where(['email' => $email])
    ->one();
    $email2=$user->email;
    $pass2=$user->pass;
    $roles_obj=$user->roles;
    $role2=$roles_obj->name;
    $id=$user->idroles;
    //echo $id;
    $user2=roles::find()
    ->where(['idroles' => $id])
    ->one();
    $role2=$user2->name;

    if ($email==$email2 && $password==$pass2) {
        $test=$role2;
    }
        //echo $name;

    return \yii\helpers\Json::encode($test);
}
public function actionFunddetail($email=0,$text='Al Meezan mutual fund')
{
    $obj1 = new \app\models\fundDetailModel();
    $this->layout = 'investorlayout';
    $this->view->params['breadcrumbs'] =$email;
    //echo $text;
    $funds=fund::find()
    ->where(['name' => $text])
    ->one();
    $id=$funds->idfund;
    $id_amc=$funds->idamc;
    $nav=nav::find()
    ->where(['idfund' => $id])
    ->all();
    $sent=sentiments::find()
    ->where(['idamc'=>$id_amc])
    ->all();
    $obj1->fundname=$funds->name;
    $obj1->founddate=$funds->founddate;
    $obj1->risk=$funds->riskfactor;
    $obj1->category=$funds->category;
    $obj1->fundmanager=$funds->fundmgname;

    for ($i=0; $i <sizeof($nav) ; $i++) { 
        $obj1->nav[$i]=$nav[$i]->value;
        $obj1->date[$i]=$nav[$i]->date;
        
    }
    for ($i=0; $i <sizeof($sent) ; $i++) { 
        if ($sent[$i]->sentiment=="1") {
            $obj1->sent[$i]="good";
            # code...
        }else
        {
            if ($sent[$i]->sentiment=="0") {
            $obj1->sent[$i]="neutral";
            # code...
        }
        else
        {
            if ($sent[$i]->sentiment=="-1") {
            $obj1->sent[$i]="Bad";
            # code...
        }
        else
        {
            $obj1->sent[$i]="";
        }
        }
        }
    }
    if (sizeof($sent)<sizeof($nav)) {
        for ($i=sizeof($sent); $i <sizeof($nav) ; $i++) { 
            $obj1->sent[$i]="";
        }
    }
    
        
    

    

    return $this->render('funddetail',['obj' => $obj1]);
}
public  function actionFundgrowth($email=0)
{
    //$test = Yii::$app->request->post('name2');
    //echo $test;
     $growth= new \app\models\growth();
     $growth->email=$email;
    $this->view->params['breadcrumbs'] =$email;
    $this->layout = 'investorlayout';
    return $this->render('detailsamc',['obj' => $growth]);
}
public function actionInvestorhome($email=0)
{

    $this->layout = 'investorlayout';
    $investors_selected_funds = new \app\models\investor_home();

    //echo $email;
  $user=userr::find()
    ->where(['email' => $email])
    ->one();
    $id_user=$user->iduserr;


    $investments=investments::find()
    ->where(['iduserr' => $id_user])
    ->all();
    if ($investments==null) {
        
    $this->view->params['breadcrumbs'] =$email;
    $investors_selected_funds->email=$email;
        # code...
        return $this->render('Investorhome',['obj' => $investors_selected_funds]);
    }
    else
    {
        for ($i=0; $i <sizeof($investments) ; $i++) { 
        $id_funds[$i]=$investments[$i]->idfund;
        $units_invest[$i]=$investments[$i]->units;
        $date_invested[$i]=$investments[$i]->invested_date;
        $funds=fund::find()
        ->where(['idfund' => $id_funds[$i]])
        ->one();
        $invested_funds[$i]=$funds->name;


    }


    for ($i=0; $i <sizeof($invested_funds) ; $i++) { 
        $investors_selected_funds->investors_funds[$i]=$invested_funds[$i];
        $investors_selected_funds->investors_investments[$i]=$units_invest[$i];
        $investors_selected_funds->date[$i]=$date_invested[$i];
        $this->view->params['breadcrumbs'] =$email;
    $investors_selected_funds->email=$email;
    }
    return $this->render('Investorhome',['obj' => $investors_selected_funds]);

    }

    

    
     
       
    


    

    
    


    
}

public function actionVinv($email=0)
{
    $this->layout = 'investorlayout';
    $this->view->params['breadcrumbs'] =$email;
    $profile = new \app\models\profile_model();
    $user=userr::find()
    ->where(['email' => $email])
    ->one();
    $profile->name=$user->name;
    $profile->email=$user->email;
    $profile->cnic=$user->cnic;
    $profile->dateofbirth=$user->dob;



    



    /*$this->layout = 'investorlayout';
    $obj = new\app\models\inv();
    $obj->name='investor1';
    $obj->amount='100000';
    $obj->email='i@gmail.com';
    $obj->dob='1st aug 2017';
    $obj->invamc[0]='Amc1';
    $obj->invamc[1]='Amc2';
    $obj->invamc[2]='Amc3';
    $obj->iamcamount[0]='15000';
    $obj->iamcamount[0]='50000';
    $obj->iamcamount[2]='35000';*/
    
    return $this->render('vinv',['obj4'=>$profile]);
}
public function actionMinv()

{

    return $this->render('minv');
}
public function actionVamc()
{
    return $this->render('vamc');
}
public function actionLoginnew()
{
    
     $this->layout = 'login_layput';
    return $this->render('loginnew');

}
public function actionAdduser($id = 0)
{
    $obj4 = new \app\models\amc_fund();
    $this->layout = 'admin_layout';
    $obj4->Amcs[0] ="NIT";
    $obj4->Amcs[1] ="meezzan";
    $obj4->Amcs[2] ="HBL";
    $obj4->Amcs[3] ="nafa";
    $obj4->Amcs[4] ="UBL";
    
    $obj4->funds[0] ="NIT";
    $obj4->funds[1] ="meezzan";
    $obj4->funds[2] ="HBL";
    $obj4->funds[3] ="nafa";
    $obj4->funds[4] ="UBL";
    
    return $this->render('AddUser',['obj4'=>$obj4]);
}
public function actionCreateportfolio($email)
{
    $this->layout = 'investorlayout';
     $this->view->params['breadcrumbs'] =$email;
     $growth1= new \app\models\growth();
     $growth1->email=$email;
    return $this->render('createportfolio',['obj'=>$growth1]);
}
public function actionDetail_fund($email,$unit,$date,$fund)
{

    $obj6 = new \app\models\detailfund();


    $fund2=fund::find()
    ->where(['name' => $fund])
    ->one();
    $id_fund=$fund2->idfund;
   $nav=nav::find()
    ->where(['idfund' => $id_fund])
    ->all();

    for ($i=0; $i <sizeof($nav) ; $i++) { 
        $obj6->date[$i]=$nav[$i]->date;
        $obj6->gain[$i]=$nav[$i]->value;
        $obj6->profit[$i]=$nav[$i]->value*$unit;
    }

    
    
    $this->layout = 'investorlayout';
     $this->view->params['breadcrumbs'] =$email;
     $obj6->email=$email;
     $obj6->unit=$unit;
     $obj6->fund_invest=$fund;

    return $this->render('detail_fund',['obj6'=>$obj6]);
}
public function actionShowportfolio($funds=0,$email=0)
{
    $this->layout = 'investorlayout';
    $this->view->params['breadcrumbs'] =$email;
    $funds_selected = explode(',', $funds);
  $obj5 = new \app\models\show_portfolio();
  for ($i=0; $i <sizeof($funds_selected) ; $i++) { 
      $obj5->fundname[$i]=$funds_selected[$i];
      
  }
  $obj5->email=$email;
  //echo $funds;

  return $this->render('showportfolio',['obj5'=>$obj5]);
}
public function actionAddfunds($funds=0,$units=0,$email=0)
{
    $this->layout = 'investorlayout';
    $this->view->params['breadcrumbs'] =$email;
    
}
}
