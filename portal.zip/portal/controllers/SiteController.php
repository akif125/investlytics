<?php

namespace app\controllers;

use Yii;
use yii\filters\AccessControl;
use yii\web\Controller;
use yii\web\Response;
use yii\filters\VerbFilter;
use app\models\LoginForm;
use app\models\ContactForm;

class SiteController extends Controller
{
    /**
     * @inheritdoc
     */
    public function behaviors()
    {
        return [
            'access' => [
                'class' => AccessControl::className(),
                'only' => ['logout'],
                'rules' => [
                    [
                        'actions' => ['logout'],
                        'allow' => true,
                        'roles' => ['@'],
                    ],
                ],
            ],
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'logout' => ['post'],
                ],
            ],
        ];
    }

    /**
     * @inheritdoc
     */
    public function actions()
    {
        return [
            'error' => [
                'class' => 'yii\web\ErrorAction',
            ],
            'captcha' => [
                'class' => 'yii\captcha\CaptchaAction',
                'fixedVerifyCode' => YII_ENV_TEST ? 'testme' : null,
            ],
        ];
    }

    /**
     * Displays homepage.
     *
     * @return string
     */
    public function actionIndex()
    {
        return $this->render('index');
    }
    public function actionTest()
    {
        
        echo 'asdjk';
    }

    /**
     * Login action.
     *
     * @return Response|string
     */
    public function actionLogin()
    {
        if (!Yii::$app->user->isGuest) {
            return $this->goHome();
        }

        $model = new LoginForm();
        if ($model->load(Yii::$app->request->post()) && $model->login()) {
            return $this->goBack();
        }
        return $this->render('login', [
            'model' => $model,
        ]);
    }

    /**
     * Logout action.
     *
     * @return Response
     */
    public function actionLogout()
    {
        Yii::$app->user->logout();

        return $this->goHome();
    }

    /**
     * Displays contact page.
     *
     * @return Response|string
     */
    public function actionContact()
    {
        $model = new ContactForm();
        if ($model->load(Yii::$app->request->post()) && $model->contact(Yii::$app->params['adminEmail'])) {
            Yii::$app->session->setFlash('contactFormSubmitted');

            return $this->refresh();
        }
        return $this->render('contact', [
            'model' => $model,
        ]);
    }

    /**
     * Displays about page.
     *
     * @return string
     */
    public function actionAbout()
    {
        return $this->render('about');
    }
    public function actionUser()
{
    return $this->render('user');
}
public function actionDemo()
{
    $mContactForm = new \app\models\ContactForm(); 
   $mContactForm->name = "contactForm"; 
   $mContactForm->email = "user@gmail.com"; 
   $mContactForm->subject = "subject"; 
   $mContactForm->body = "body";
   return $this->render('demo',['message' => $mContactForm]);
}
public function actionAdminhome($test=0,$email=0)
{
    // echo $email;
    // echo " ";
    // echo $password;
    $this->layout = 'investorlayout';
    $obj1 = new \app\models\fm1();
    //echo $test;
    $this->view->params['breadcrumbs'] =$email;
    //echo $email;
   if ($test=="NIT") {
            $obj1->funds[0]="NIUT";
            $obj1->funds[1]="NIUTEQ";
            $obj1->funds[2]="NIT GTF";
            $obj1->Amcs="NIT";
            $obj1->email=$email;
        }
        if ($test=="meezan") {
           $obj1->funds[0]="MIF(Meezan islamic fund)";
           $obj1->funds[1]="MCF(Meezan cash fund)";
           $obj1->funds[2]="MBF(Meezan balanced fund)"; 
            $obj1->Amcs="meezan";
            $obj1->email=$email;
        }
        if ($test=="HBL") {
            $obj1->funds[0]="HBL equity fund";
            $obj1->funds[1]="HBL cash fund";
            $obj1->funds[2]="HBL money market fund";
            $obj1->Amcs="HBL";
            $obj1->email=$email;
        }
        
    
    


    return $this->render('adminviewamc',['message' => $obj1]);
}
public function actionAdminviewamc()
{
    // echo $email;
    // echo " ";
    // echo $password;
   
    $obj = new \app\models\fm1();
    $obj->Amcs[0] ="NIT";
    $obj->Amcs[1] ="meezzan";
    $obj->Amcs[2] ="HBL";
    $obj->Amcs[3] ="nafa";
    $obj->Amcs[4] ="UBL";
    


    return $this->render('adminviewamc',['message' => $obj]);
}
public function actionDetailsamc()
{

        $obj1 = new \app\models\amc1();
        $test = Yii::$app->request->post('name');
        
        if ($test=="NIT") {
            $obj1->funds[0]="NIUT";
            $obj1->funds[1]="NIUTEQ";
            $obj1->funds[2]="NIT GTF";
        }
        if ($test=="Meezan") {
           $obj1->funds[0]="MIF(Meezan islamic fund)";
           $obj1->funds[1]="MCF(Meezan cash fund)";
           $obj1->funds[2]="MBF(Meezan balanced fund)"; 
        }
        if ($test=="HBL") {
            $obj1->funds[0]="HBL equity fund";
            $obj1->funds[1]="HBL cash fund";
            $obj1->funds[2]="HBL money market fund";
        }
        
    

    // return Json    
    return \yii\helpers\Json::encode($obj1);
    
}
public function actionLogin2()
{
    $email = Yii::$app->request->post('email');
    $password = Yii::$app->request->post('password');
    $test="error";
    if ($email=="admin@gmail.com" && $password=="admin") {
        $test="admin";
    }
    elseif ($email=="investor@gmail.com" && $password == "investor") {
        $test="investor";
    }
    elseif($email=="fundm@gmail.com" && $password == "fundm"){
        $test="fundmanager";
    }

    return \yii\helpers\Json::encode($test);
}
public function actionFunddetail($email=0,$text=0)
{
    $this->layout = 'investorlayout';
    $this->view->params['breadcrumbs'] =$email;
    return $this->render('funddetail');
}
public  function actionFundgrowth($email=0)
{
    //$test = Yii::$app->request->post('name2');
    //echo $test;
     $growth= new \app\models\growth();
     $growth->email=$email;
    $this->view->params['breadcrumbs'] =$email;
    $this->layout = 'investorlayout';
    return $this->render('detailsamc',['obj' => $growth]);
}
public function actionInvestorhome($email=0)
{

    $this->layout = 'investorlayout';
    $investors_selected_funds = new \app\models\investor_home();
    $investors_selected_funds->investors_funds[0]="Al Meezan Mutual Fund IEQ";
    $investors_selected_funds->investors_funds[1]="Al Meezan Cash Fund IMM";
    $investors_selected_funds->investors_funds[2]="NIT GTF MM";
    $investors_selected_funds->investors_funds[3]="NAFA Moneymarket MM";
    $investors_selected_funds->investors_investments[0]="2";
    $investors_selected_funds->investors_investments[1]="1";
    $investors_selected_funds->investors_investments[2]="3";
    $investors_selected_funds->investors_investments[3]="5";
    $investors_selected_funds->date[0]="30-aug-17";
    $investors_selected_funds->date[1]="30-july-17";
    $investors_selected_funds->date[2]="1-aug-17";
    $investors_selected_funds->date[3]="2-aug-17";

    $this->view->params['breadcrumbs'] =$email;
    $investors_selected_funds->email=$email;

    
    

    
    


    return $this->render('Investorhome',['obj' => $investors_selected_funds]);
}
public function actionVinv()
{
    $this->layout = 'investorlayout';
    $obj = new\app\models\inv();
    $obj->name='investor1';
    $obj->amount='100000';
    $obj->email='i@gmail.com';
    $obj->dob='1st aug 2017';
    $obj->invamc[0]='Amc1';
    $obj->invamc[1]='Amc2';
    $obj->invamc[2]='Amc3';
    $obj->iamcamount[0]='15000';
    $obj->iamcamount[0]='50000';
    $obj->iamcamount[2]='35000';
    
    return $this->render('vinv',['message' => $obj]);
}
public function actionMinv()

{

    return $this->render('minv');
}
public function actionVamc()
{
    return $this->render('vamc');
}
public function actionLoginnew()
{
    
     $this->layout = 'login_layput';
    return $this->render('loginnew');

}
public function actionAdduser($id = 0)
{
    $obj4 = new \app\models\amc_fund();
    $obj4->Amcs[0] ="NIT";
    $obj4->Amcs[1] ="meezzan";
    $obj4->Amcs[2] ="HBL";
    $obj4->Amcs[3] ="nafa";
    $obj4->Amcs[4] ="UBL";
    
    $obj4->funds[0] ="NIT";
    $obj4->funds[1] ="meezzan";
    $obj4->funds[2] ="HBL";
    $obj4->funds[3] ="nafa";
    $obj4->funds[4] ="UBL";
    
    return $this->render('AddUser',['obj4'=>$obj4]);
}
public function actionCreateportfolio($email)
{
    $this->layout = 'investorlayout';
     $this->view->params['breadcrumbs'] =$email;
     $growth1= new \app\models\growth();
     $growth1->email=$email;
    return $this->render('createportfolio',['obj'=>$growth1]);
}
public function actionDetail_fund($email,$unit,$date,$fund)
{

    $obj6 = new \app\models\detailfund();
    if ($fund=="Al Meezan Mutual Fund IEQ") {
    $obj6->date[0]="30-june-17";
    $obj6->date[1]="30-july-17";
    $obj6->date[2]="30-august-17";
    $obj6->date[3]="30-september-17";
    $obj6->date[4]="30-october-17";
    $obj6->date[5]="30-november-17";
    $obj6->gain[0]="13.7";
    $obj6->gain[1]="13.8";
    $obj6->gain[2]="12.1";
    $obj6->gain[3]="12.4";
    $obj6->gain[4]="15.2";
    $obj6->gain[5]="11.7";

        # code...
    }
    if ($fund=="Al Meezan Cash Fund IMM") {
        $obj6->date[0]="30-april-17";
    $obj6->date[1]="30-may-17";
    $obj6->date[2]="30-august-17";
    $obj6->date[3]="30-september-17";
    $obj6->date[4]="30-october-17";
    $obj6->date[5]="30-november-17";
    $obj6->gain[0]="14.7";
    $obj6->gain[1]="12.8";
    $obj6->gain[2]="17.1";
    $obj6->gain[3]="11.4";
    $obj6->gain[4]="20.2";
    $obj6->gain[5]="21.7";
        # code...
    }
    
    $this->layout = 'investorlayout';
     $this->view->params['breadcrumbs'] =$email;
     $obj6->email=$email;
     $obj6->unit=$unit;
     $obj6->fund=$fund;

    return $this->render('detail_fund',['obj6'=>$obj6]);
}
public function actionShowportfolio($funds=0,$email=0)
{
    $this->layout = 'investorlayout';
    $this->view->params['breadcrumbs'] =$email;
    $funds_selected = explode(',', $funds);
  $obj5 = new \app\models\show_portfolio();
  for ($i=0; $i <sizeof($funds_selected) ; $i++) { 
      $obj5->fundname[$i]=$funds_selected[$i];
      
  }
  return $this->render('showportfolio',['obj5'=>$obj5]);
}
}
