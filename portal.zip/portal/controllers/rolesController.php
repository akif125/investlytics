<?php
namespace app\controllers;
use yii\web\controller;
use app\model\roles;

class rolesController extends Controller
{
	public function actionTest()
    {
        /*$roles = roles::find()
    ->where(['id' => 1])
    ->one();*/
        echo 'strings';
    }
}


  ?>