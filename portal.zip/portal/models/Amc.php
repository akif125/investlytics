<?php
namespace app\models;

use yii\db\ActiveRecord;

class Amc extends ActiveRecord
{
    /*public $idroles;
    public $name;*/
    
    /**
     * @return string the name of the table associated with this ActiveRecord class.
     */
    public static function tableName()
    {
        return '{{amc}}';
    }
    public static function getDb()
    {
        // use the "db2" application component
        return \Yii::$app->db;  
    }
    public function getfund()
    {
        return $this->hasMany(fund::className(), ['idamc' => 'idfund']);
    }
}


  ?>