<?php
namespace app\models;

use yii\db\ActiveRecord;

class Roles extends ActiveRecord
{
    /*public $idroles;
    public $name;*/
    
    /**
     * @return string the name of the table associated with this ActiveRecord class.
     */
    public static function tableName()
    {
        return '{{roles}}';
    }
    public static function getDb()
    {
        // use the "db2" application component
        return \Yii::$app->db;  
    }
    public function getuserr()
    {
        return $this->hasMany(userr::className(), ['iduserr' => 'idroles']);
    }
}


  ?>