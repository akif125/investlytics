<?php
namespace app\models;

use yii\db\ActiveRecord;

class Userr extends ActiveRecord
{
    /*public $idroles;
    public $name;*/
    
    /**
     * @return string the name of the table associated with this ActiveRecord class.
     */
    public static function tableName()
    {
        return '{{userr}}';
    }
    public static function getDb()
    {
        // use the "db2" application component
        return \Yii::$app->db;  
    }
    public function getroles()
    {
        return $this->hasOne(roles::className(), ['idroles' => 'iduserr']);
    }
    public function getinvestments()
    {
        return $this->hasMany(investments::className(), ['iduserr' => 'idfund']);
    }
}


  ?>