<?php
namespace app\models;

use Yii;
use yii\base\Model;
class amc1 extends Model
{
public $funds;
public $xco;
public $yco;
public $image_name;

public function rules()
    {
        return [
            
            [['funds', 'xco', 'yco'], 'required'],
            
        ];
    }
}
  ?>


