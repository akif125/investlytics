<?php
namespace app\models;

use Yii;
use yii\base\Model;
class amc_fund extends Model
{
public $Amcs;
public $funds;

public function rules()
    {
        return [
            
            [['Amcs','funds'], 'required'],
            
        ];
    }
}
  ?>
