<?php
namespace app\models;

use Yii;
use yii\base\Model;
class detailfund extends Model
{
public $fund;
public $date;
public $gain;
public $email;
public $unit;

public function rules()
    {
        return [
            
            [['funds', 'date', 'gain','email','unit'], 'required'],
            
        ];
    }
}
  ?>


