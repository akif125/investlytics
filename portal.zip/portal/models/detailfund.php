<?php
namespace app\models;

use Yii;
use yii\base\Model;
class detailfund extends Model
{
public $fund_invest;
public $date;
public $gain;
public $email;
public $unit;
public $profit;

public function rules()
    {
        return [
            
            [['funds', 'date', 'gain','email','unit'], 'required'],
            
        ];
    }
}
  ?>


