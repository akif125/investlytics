<?php
namespace app\models;

use Yii;
use yii\base\Model;
class fundDetailModel extends Model
{
public $nav;
public $date;
public $fundname;
public $founddate;
public $risk;
public $category;
public $fundmanager;
public $sent;

public function rules()
    {
        return [
            
            [['nav','date','fundname','founddate','founddate','risk','category','fundmanager'], 'required'],
            
        ];
    }
}
  ?>
