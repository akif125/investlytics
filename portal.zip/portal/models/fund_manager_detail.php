<?php
namespace app\models;

use Yii;
use yii\base\Model;
class fund_manager_detail extends Model
{
public $fundmanager;
public $xco;
public $yco; 
public $fundname;
public function rules()
    {
        return [
            
            [['fundmanager', 'xco', 'yco','fundname'], 'required'],
            
        ];
    }
}
  ?>
