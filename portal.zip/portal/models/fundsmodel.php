<?php
namespace app\models;

use Yii;
use yii\base\Model;
class fm1 extends Model
{
public $funds;

public function rules()
    {
        return [
            
            ['funds', 'required'],
            
        ];
    }
}
  ?>
