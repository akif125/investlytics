<?php
namespace app\models;

use Yii;
use yii\base\Model;
class growth extends Model
{

public $email;

public function rules()
    {
        return [
            
            ['email', 'required'],
            
        ];
    }
}
  ?>
