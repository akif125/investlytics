<?php
namespace app\models;

use Yii;
use yii\base\Model;
class inv extends Model
{
public $name;
public $amount;
public $email;
public $dob;
public $invamc;
public $iamcamount;

public function rules()
    {
        return [
            
            [['name', 'amount', 'email','dob','invamc','iamcamount'], 'required'],
            
        ];
    }
}
  ?>


