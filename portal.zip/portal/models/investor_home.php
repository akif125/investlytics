<?php
namespace app\models;

use Yii;
use yii\base\Model;
class investor_home extends Model
{
public $investors_funds;
public $investors_investments;
public $date;
public $email;

public function rules()
    {
        return [
            
            ['investors_funds', 'required'],
            
        ];
    }
}
  ?>
