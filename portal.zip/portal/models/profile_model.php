<?php
namespace app\models;

use Yii;
use yii\base\Model;
class profile_model extends Model
{
public $email;
public $cnic;
public $name;
public $dateofbirth;


public function rules()
    {
        return [
            
            [['email', 'cnic', 'name','dateofbirth'], 'required'],
            
        ];
    }
}
  ?>


