<?php
namespace app\models;

use Yii;
use yii\base\Model;
class recomdation_model extends Model
{
public $funds;
public $nav;
public $nav_actual;

public function rules()
    {
        return [
            
            [['funds','nav'], 'required'],
            
        ];
    }
}
  ?>


