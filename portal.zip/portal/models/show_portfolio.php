<?php
namespace app\models;

use Yii;
use yii\base\Model;
class show_portfolio extends Model
{
public $fundname;
public function rules()
    {
        return [
            
            ['fundname', 'required'],
            
        ];
    }
}
  ?>
