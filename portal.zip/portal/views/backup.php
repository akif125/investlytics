<!DOCTYPE html>
<html>
<head>
	<?php use yii\helpers\Html;
	
  ?>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<style type="text/css">

	.text
	{
		font-size: 20px;
		color: white;
		cursor:pointer;
	}
	.userhead
	  	{
	  		font-size: 50px;
	  		font-family: bold;
	  		color: grey;


	  	}
	.sidenav {
    height: 100%;
    width: 0;
    
   
    top: 0;
    left: 0;
    background-color: grey;
    overflow-x: hidden;
    transition: 0.5s;
    padding-top: 60px;
    border-radius: 10px;
}

.sidenav a {
    padding: 8px 8px 8px 32px;
    text-decoration: none;
    font-size: 25px;
    color: #818181;
    display: block;
    transition: 0.3s;
}

.sidenav a:hover {
    color: #f1f1f1;
}

.sidenav .closebtn {
    position: absolute;
    top: 0;
    right: 25px;
    font-size: 36px;
    margin-left: 50px; 
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}

</style>
<script>
	var count=0;
	function openNav() {
		if (count==0) { 
			document.getElementById("mySidenav").style.width = "250px";
			document.getElementById("mySidenav").style.border = "2px solid black";
			document.getElementById("arrow").innerHTML="&#10229;";
			

		count=1;
	}
		else{closeNav()}
   
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
    document.getElementById("mySidenav").style.border = "0px";
    document.getElementById("arrow").innerHTML="&#10230;";
   
    count=0;
}
	
	function render_page2(id)
	{
         var test2=document.getElementById(id).innerHTML;
		/*$.ajax({
                type: "POST",
                url: "index.php?r=site%2Ffundgrowth",
                data: { 'na': 'asadssss'}
                
                
                
            });*/
		//alert(document.getElementById(id).innerHTML);
		window.location.href= 'index.php?r=site%2Ffundgrowth&id='+test2;

		
	}

	function gedata(id)
	{
		var x = document.getElementsByClassName("text");
		for (var i = x.length - 1; i >= 0; i--) {
			x[i].style.color="white";
		}
    	
		document.getElementById(id).style.color = "black";
		var y=document.getElementById(id);
		var z=y.innerHTML;

		
		passdata(z);
}
	function passdata(z)
	{
		var test = z;
		
        $.ajax({
                type: "post",
                url: "index.php?r=site%2Fdetailsamc",
                data: {'name' : test},
            	dataType: "json",
                success: function (data) {
                    
                	var t=document.getElementById('fundlist2');
		    		t.innerHTML="";
                   for (var i = data.funds.length - 1; i >= 0; i--) {
				el = document.createElement('li');
			    el.innerHTML = data.funds[i];
			    el.id=data.funds[i]+i;
			    el.style.cursor ="pointer";
			    document.getElementById('fundlist2').appendChild(el);
			    el.onclick=function() {render_page2(this.id)};
			}

                },
                error: function (exception) {
                    alert(JSON.stringify(exception));
                }
            })
            ;

         

        
	}
	function go_addUser(){
		window.location.href="http://localhost/portal/web/index.php?r=site%2Fadduser";
	}

	
</script>	
</head>
<body>
	<div class="row">
		<div class="col-xs-12 col-sm-12">
			<p class="userhead">View AMC'S</p>
		</div>
	</div>
	<div class="row">
		<div class="col-xs-6 col-sm-6 col-md-6">

			<span style="font-size:30px;cursor:pointer;color: grey;size: 100px;" onclick="openNav()" id="arrow">&#10230;</span>
			<div id="mySidenav" class="sidenav">
			  <ul>
				<?php for ($i=0; $i <sizeof($message->Amcs) ; $i++) {  ?>
			       <li style="color: white"><p class="text" id="text-<?php echo $i; ?>" onclick="gedata(this.id)"><?= Html::encode($message->Amcs[$i]) ?></p></li>
				<?php }  ?>
			</ul>
			</div>
		</div>
		<div class="col-xs-6 col-sm-6 col-md-6">
			<div id="fundlist1">
						<ul id="fundlist2">
							
						</ul>
					</div>
		</div>
	</div>




</body>
</html>