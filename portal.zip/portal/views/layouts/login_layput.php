<!DOCTYPE html>
<html lang="en">
<head>
  <title>Investlytics</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
 
  <style type="text/css">

  .text
  {
    font-size: 20px;
    color: black;
    cursor:pointer;
  }
  body {
    font-family: "Lato", sans-serif;
    transition: background-color .5s;
}
  .navbar{
    height: 80px;
    background-color: #223c65;
    color: #FFFFFF;
  }
  .navbar-brand{
    height: 80px;
    background-color: #223c65;
    color: #FFFFFF;
  }

  .navbar a{
    font-family: "Lato", sans-serif;
    padding-top: 10px;
    text-decoration: none;
    font-size: 15px;
    color: #FFFFFF;
    display: block;
}

.sidenav {
    height: 100%;
    width: 0;
    position: fixed;
    z-index: 1;
    top: 80px;
    left: -80;
    background-color: #223c65;
    overflow-x: hidden;
    transition: 0.5s;
    padding-top: 60px;
}

.sidenav a {
    padding: 10px 8px 8px 32px;
    text-decoration: none;
    font-size: 25px;
    color: #FFFFFF;
    display: block;
    transition: 0.3s;
}

.sidenav a:hover {
    color: #818181;
}

.sidenav .closebtn {
    position: absolute;
    top: 0;
    right: 25px;
    font-size: 36px;
    margin-left: 50px;
    color: #FFFFFF;
}

#main {
    
    padding: 16px;
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}

  </style>

  <script type="text/javascript">

/* Set the width of the side navigation to 250px and the left margin of the page content to 250px and add a black background color to body */
// function openNav() {
//     document.getElementById("mySidenav").style.width = "250px";
//     document.getElementById("main").style.marginLeft = "250px";
//     document.body.style.backgroundColor = "rgba(0,0,0,0.4)";
// }

//  Set the width of the side navigation to 0 and the left margin of the page content to 0, and the background color of body to white 
// function closeNav() {
//     document.getElementById("mySidenav").style.width = "0";
//     document.getElementById("main").style.marginLeft = "0";
//     document.body.style.backgroundColor = "white";
// }
function openNav() {
    document.getElementById("mySidenav").style.width = "220px";
    document.getElementById("main").style.marginLeft = "220px";
    //document.body.style.backgroundColor = "rgba(0,0,0,0.4)";
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
    document.getElementById("main").style.marginLeft= "0";
    document.body.style.backgroundColor = "white";
}
function go_to_view(id)
      {
          var txt=document.getElementById(id).innerHTML;
          var email=document.getElementById("email").innerHTML;
          //alert(email);
         window.location.href="index.php?r=site%2Fadminhome";
      }
      function onGO_profile()
      {

      }
      onGO_home()
      {
        
        //alert(email);
        window.location.href="index.php?r=site%&email="+email;
      }

  </script>
</head>
<body>


 
<nav class="navbar navbar-fixed-top">
  <div class="container-fluid">
    <div class="navbar-header"  >
      <a class="navbar-brand" href="#" style="font-size: 25px"><img src="img/Untitled.png" alt="<b><i>Investlytics</i></b>" height="60px" width="250px"></a>
    </div>
    <ul class="nav navbar-nav navbar-right" style="padding-top: 15px">
      <li><a href="#;font-family: "Lato", sans-serif;"><span class="glyphicon glyphicon-user"></span> About us</a></li>
      <li><a href="#"><span class="glyphicon glyphicon-earphone"></span>Contact</a></li>
      <li><a href="index.php?r=site%2Floginnew"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>

    </ul>
  </div>
 
</nav>
<!-- Use any element to open the sidenav -->
 

<!-- Add all page content inside this div if you want the side nav to push page content to the right (not used if you only want the sidenav to sit on top of the page -->
<div class="container" style="margin-top:70px">

</div> 

      
    <div id="main" class="main">
  
    
      <?= $content ?> 
    
    </div>
  

    <!-- Bootstrap core JavaScript-->
    <script src="../views/layouts/jquery/jquery.min.js"></script>
    <script src="../views/layouts/popper/popper.min.js"></script>
    <script src="../views/layouts/bootstrap/js/bootstrap.min.js"></script>
    <!-- Core plugin JavaScript-->
    <script src="../views/layouts/jquery-easing/jquery.easing.min.js"></script>
    <!-- Page level plugin JavaScript-->
    <script src="../views/layouts/chart.js/Chart.min.js"></script>
    <script src="../views/layouts/datatables/jquery.dataTables.js"></script>
    <script src="../views/layouts/datatables/dataTables.bootstrap4.js"></script>
    <!-- Custom scripts for all pages-->
    <script src="../views/layouts/js/sb-admin.min.js"></script>
    <!-- Custom scripts for this page-->
    <script src="../views/layouts/js/sb-admin-datatables.min.js"></script>
    <script src="../views/layouts/js/sb-admin-charts.min.js"></script>
  
</div>    
</body>
</html>
