<!DOCTYPE html>
<html>
<head>
<?php use yii\helpers\Html;
  use yii\helpers\Url;
  
  ?>
<meta charset="utf-8">

  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<style type="text/css">
	.text
	{
		font-size: 20px;
		color: black;
		cursor:pointer;
	}
	button.accordion {
    background-color: white;
    color: #444;
    cursor: pointer;
    padding: 18px;
    width: 100%;
    border: none;
    text-align: left;
    outline: none;
    font-size: 20px;
    transition: 0.4s;
}
.userhead
	  	{
	  		font-size: 50px;
	  		font-family: bold;
	  		color: grey;

	  	}

button.accordion.active, button.accordion:hover {
    background-color: #ccc; 
}

div.panel {
    padding: 0 18px;
    display: none;
    background-color: white;
}
</style>
<script type="text/javascript">
	function detail_growth(id)
  {
    var date_id="date-"+id;
    var unit_id="unit-"+id;
    var date=document.getElementById(date_id).innerHTML;
    var unit=document.getElementById(unit_id).innerHTML;
    var fund=document.getElementById(id).innerHTML;
    var email="<?= Html::encode($obj->email) ?>";
    //alert(fund +" "+unit+" "+date);
    //alert(email);
    window.location.href='index.php?r=site%2Fdetail_fund&email='+email+"&unit="+unit+"&date="+date+"&fund="+fund;
  }
	


	
</script>	
		
</head>
<body>
  

  <div class="row">
    <div class="col-xs-12 col-sm-12">
      <p class="userhead">Your Investments</p>
    </div>
  </div>
  <table class="table table-striped">
    <thead>
      <tr>
        <th>#</th>
        <th>Funds</th>
        <th>Units</th>
        <th>Date</th>

      </tr>
    </thead>
    <tbody>
        <?php for ($i=0; $i <sizeof($obj->investors_funds) ; $i++) {  ?>
                  <tr>
                    <td><?= $i+1 ?></td>
                    <td onclick="detail_growth(this.id)" style="cursor: pointer;" id="<?php echo $i; ?>" ><?= Html::encode($obj->investors_funds[$i]) ?></td>
                  <td id="unit-<?php echo $i; ?>"><?= Html::encode($obj->investors_investments[$i]) ?></td>
                  <td id="date-<?php echo $i; ?>"><?= Html::encode($obj->date[$i]) ?></td>
                </tr>
             
        <?php }  ?>
        
      
      
    </tbody>
  </table>
</div>


</body>
</html>
