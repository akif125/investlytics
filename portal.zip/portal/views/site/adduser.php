<!DOCTYPE html>
<html>
<head>
	<?php use yii\helpers\Html;
	
  ?>
	<meta charset="utf-8">
	  <meta name="viewport" content="width=device-width, initial-scale=1">
	  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
	  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	  <style type="text/css">
	  	.userhead
	  	{
	  		font-size: 50px;
	  		font-family: bold;
	  		color: grey;

	  	}
	  	.textboxstyle
	  	{
	  		border-radius: 10px;
	  		width: 50%;
	  		margin-bottom: 5px;
	  		
	  	}
	  </style>
	  <script type="text/javascript">
	  	function select_amc_text()
	  	{
	  			var div_row_select=document.createElement("DIV");
	  			var div_col_select=document.createElement("DIV");
	  			var attr_row_select=document.createAttribute("class");
	  			attr_row_select.value="row";
	  			var attr_col_select=document.createAttribute("class");
	  			attr_col_select.value="col-xs-12 col-sm-12";
	  			div_row_select.setAttributeNode(attr_row_select);
	  			div_col_select.setAttributeNode(attr_col_select);
	  			var selecttag=document.createElement("SELECT");
	  			var attr_select_name=document.createAttribute("name");
	  			attr_select_name.value="selectamc";
	  			selecttag.setAttributeNode(attr_select_name);
	  			var attr_select_class=document.createAttribute("class");
	  			attr_select_class.value="textboxstyle";
	  			selecttag.setAttributeNode(attr_select_class);

	  			var attr_select_style=document.createAttribute("style");
	  			attr_select_style.value="width: 120px !important";
	  			selecttag.setAttributeNode(attr_select_style);
	  			var attr_select_id=document.createAttribute("id");
	  			attr_select_id.value="amc";
	  			selecttag.setAttributeNode(attr_select_id);


	  			var optiontag1=document.createElement("OPTION");
	  			var attr_value_option=document.createAttribute("value");
	  			attr_value_option.value="habbib";
	  			optiontag1.innerHTML="Habbib";
	  			optiontag1.setAttributeNode(attr_value_option);
	  			selecttag.appendChild(optiontag1);
	  			var optiontag2=document.createElement("OPTION");
	  			var attr_value_option2=document.createAttribute("value");
	  			attr_value_option2.value="nit";
	  			optiontag2.innerHTML="NIT";
	  			optiontag2.setAttributeNode(attr_value_option2);
	  			selecttag.appendChild(optiontag2);
	  			var optiontag3=document.createElement("OPTION");
	  			var attr_value_option3=document.createAttribute("value");
	  			attr_value_option3.value="nafa";
	  			optiontag3.innerHTML="NAFA";
	  			optiontag3.setAttributeNode(attr_value_option3);
	  			selecttag.appendChild(optiontag3);
	  			div_col_select.appendChild(selecttag);
	  			div_row_select.appendChild(div_col_select);
	  			document.getElementById("contain").appendChild(div_row_select);
	  	}
	  	function select_fund_text()
	  	{
	  		var div_row_select=document.createElement("DIV");
	  			var div_col_select=document.createElement("DIV");
	  			var attr_row_select=document.createAttribute("class");
	  			attr_row_select.value="row";
	  			var attr_col_select=document.createAttribute("class");
	  			attr_col_select.value="col-xs-12 col-sm-12";
	  			div_row_select.setAttributeNode(attr_row_select);
	  			div_col_select.setAttributeNode(attr_col_select);
	  			var selecttag=document.createElement("SELECT");
	  			var attr_select_name=document.createAttribute("name");
	  			attr_select_name.value="selectamc";
	  			selecttag.setAttributeNode(attr_select_name);
	  			var attr_select_class=document.createAttribute("class");
	  			attr_select_class.value="textboxstyle";
	  			selecttag.setAttributeNode(attr_select_class);

	  			var attr_select_style=document.createAttribute("style");
	  			attr_select_style.value="width: 120px !important";
	  			selecttag.setAttributeNode(attr_select_style);
	  			var attr_select_id=document.createAttribute("id");
	  			attr_select_id.value="fund";
	  			selecttag.setAttributeNode(attr_select_id);


	  			var optiontag1=document.createElement("OPTION");
	  			var attr_value_option=document.createAttribute("value");
	  			attr_value_option.value="Al Meezan Mutual Fund IEQ";
	  			optiontag1.innerHTML="Al Meezan Mutual Fund IEQ";
	  			optiontag1.setAttributeNode(attr_value_option);
	  			selecttag.appendChild(optiontag1);
	  			var optiontag2=document.createElement("OPTION");
	  			var attr_value_option2=document.createAttribute("value");
	  			attr_value_option2.value="Al Meezan Cash Fund IMM";
	  			optiontag2.innerHTML="Al Meezan Cash Fund IMM";
	  			optiontag2.setAttributeNode(attr_value_option2);
	  			selecttag.appendChild(optiontag2);
	  			var optiontag3=document.createElement("OPTION");
	  			var attr_value_option3=document.createAttribute("value");
	  			attr_value_option3.value="Al Meezan Islamic Fund IEQ";
	  			optiontag3.innerHTML="Al Meezan Islamic Fund IEQ";
	  			optiontag3.setAttributeNode(attr_value_option3);
	  			selecttag.appendChild(optiontag3);
	  			div_col_select.appendChild(selecttag);
	  			div_row_select.appendChild(div_col_select);
	  			document.getElementById("contain").appendChild(div_row_select);
	  	}
	  	function signup_function()
	  	{

	  		var user_type=document.getElementById("usertype");
	  		if (user_type.value=="fund manager") {
	  			//alert("ok");
	  		}
	  		if (user_type.value=="investor") {
	  			//alert("nok")
	  		}
	  		//alert(user_type.value);
	  	}


	  	function check(period)
	  	{
	  		
	  		
	  		if (period=="fund manager") {
	  			//alert("investor");
	  			document.getElementById("contain").innerHTML=""; 
	  			select_amc_text();
	  			select_fund_text();

	  			
	  			var div_row=document.createElement("DIV");
	  			var div_col=document.createElement("DIV");
	  			var class_row=document.createAttribute("class");
	  			var class_col=document.createAttribute("class");
	  			class_row.value="row";
	  			class_col.value="col-xs-12 col-sm-12";
	  			div_row.setAttributeNode(class_row);
	  			div_col.setAttributeNode(class_col);
	  			var btn=document.createElement("BUTTON");
	  			var att_btn_class=document.createAttribute("class");
	  			att_btn_class.value="btn-success";
	  			btn.setAttributeNode(att_btn_class);
	  			var attr_btn_onclick=document.createAttribute("onClick");
	  			attr_btn_onclick.value="signup_function()";
	  			btn.setAttributeNode(attr_btn_onclick);
	  			btn.innerHTML="ADD";
	  			div_col.appendChild(btn);
	  			div_row.appendChild(div_col);
	  			var element2 = document.getElementById("contain");
	  			element2.appendChild(div_row);
	  			




	  			
	  			//document.getElementById("contain").appendChild(div_row_select);

	  			//document.getElementById("usertype").disabled=true;




	  		}
	  		if (period=="investor") {
	  			document.getElementById("contain").innerHTML="";

	  			var div_row=document.createElement("DIV");
	  			var div_col=document.createElement("DIV");
	  			var class_row=document.createAttribute("class");
	  			var class_col=document.createAttribute("class");
	  			class_row.value="row";
	  			class_col.value="col-xs-12 col-sm-12";
	  			div_row.setAttributeNode(class_row);
	  			div_col.setAttributeNode(class_col);
	  			var btn=document.createElement("BUTTON");
	  			var att_btn_class=document.createAttribute("class");
	  			att_btn_class.value="btn-success";
	  			btn.setAttributeNode(att_btn_class);
	  			var attr_btn_onclick=document.createAttribute("onClick");
	  			attr_btn_onclick.value="signup_function()";
	  			btn.setAttributeNode(attr_btn_onclick);
	  			btn.innerHTML="ADD";
	  			div_col.appendChild(btn);
	  			div_row.appendChild(div_col);
	  			var element = document.getElementById("contain");
	  			element.appendChild(div_row);
	  			//document.getElementById("usertype").disabled=true;
	  		}
	  		if (period=="") {
	  			document.getElementById("contain").innerHTML="";
	  		}
	  		
	  	}
	  </script>
</head>
<body>
<div class="container">
	<div class="row">
		<div class="col-xs-12 col-sm-12">
			<p class="userhead">ADD USER</p>
		</div>
	</div>
	<div calss="row">
		<div calss="col-xs-12 col-sm-12">
			<input type="text" name="name" class="textboxstyle" placeholder="Name" id="name">
		</div>
	</div>
	<div class="row">
		<div class="col-xs-12 col-sm-12"><input type="text" name="cnic" class="textboxstyle" placeholder="CNIC" id="cnic"></div>
	</div>
	<div class="row">
		<div class="col-xs-12 col-sm-12">
			<input type="text" name="email" class="textboxstyle" placeholder="Email" id="email">
		</div>
	</div>
	<div class="row">
		<div class="col-xs-12 col-sm-12">
			<input type="text" name="password" class="textboxstyle" placeholder="Password" id="password">
		</div>
	</div>
	<div class="row">
		<div class="col-xs-12 col-sm-12">
			<input type="text" name="confirm password" class="textboxstyle" placeholder="Confirm password" id="confirm">
		</div>
	</div>
	
	<div class="row">
		<div class="col-x-12 col-sm-12">
			<input type="date" name="date" id="date" class="textboxstyle" style="width: 150px !important">
		</div>
	</div>
	<div class="row">
		<div class="col-xs-12 col-sm-12">
			<select name="usertype" onchange="check(this.value)" id="usertype" class="textboxstyle" style="width: 120px !important">
				<option value=""></option>
				<option value="investor" >Investor</option>
				<option value="fund manager" >Fund manager</option>

			</select>
		</div>
	</div>
	<div class="row">
		<div class="col-xs-12 col-sm-12" id="contain">
			
		</div>
	</div>

	
</div>
</body>
</html>