<!DOCTYPE html>
<html>
<head>
	<?php use yii\helpers\Html;
	
  ?>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<style type="text/css">

	.text
	{
		font-size: 20px;
		color: black;
		cursor:pointer;
	}
		button.accordion {
    background-color: white;
    color: #444;
    cursor: pointer;
    padding: 18px;
    width: 100%;
    border: none;
    text-align: left;
    outline: none;
    font-size: 20px;
    transition: 0.4s;
}
.userhead
	  	{
	  		font-size: 50px;
	  		font-family: bold;
	  		color: grey;

	  	}

button.accordion.active, button.accordion:hover {
    background-color: #ccc; 
}

div.panel {
    padding: 0 18px;
    display: none;
    background-color: white;
}
</style>
<script>
	
	
	function va(){
		window.location.href="http://localhost/portal/web/index.php?r=site%2Fadminviewamc";
	}
	function as(){
		window.location.href="http://localhost/portal/web/index.php?r=site%2Fadduser";
	}

	
</script>	
</head>
<body>

<div class="container">

	<div calss="row">
		<h1 align="left" class="userhead">Admin Home</h1>
		<div class="col-xs-6 col-sm-4 col-md-2">

			<div class="row">
					
	<div class="col-xs-12 col-sm-12">
		<button class="accordion" id="b1" onclick="va(this.id)">View Amcs</button>
					
					
				</div>
				<div class="col-xs-12 col-sm-12">
		<button class="accordion" id="b2" onclick="as(this.id)">Add Subscribers</button>
					
					
				</div>
			</div>
</div>
</body>
</html>