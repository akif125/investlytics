<!DOCTYPE html>
<html>
<head>
	<?php use yii\helpers\Html;
	use yii\helpers\Url;
	
  ?>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<style type="text/css">
.card {
    box-shadow: 0 4px 8px 0 rgba(2,0,0,0.0);
    transition: 0.3s;
    width: 60%;
}

.card:hover {
    box-shadow: 0 8px 16px 0 rgba(0,0,0,0.2);
}

.contain {
    padding: 2px 16px;
    background-color: lightblue;
    height: 100px;
}
.userhead
	  	{
	  		font-size: 50px;
	  		font-family: bold;
	  		color: grey;


	  	}
	
</style>
    <script type="text/javascript">
    function go_to_growth(id)
        {
        	var fullid="fund"+id;
        	var email="<?= Html::encode($message->email) ?>";
        	var text=document.getElementById(fullid).innerHTML;
        	//alert(id);
            window.location.href='index.php?r=site%2Ffunddetail&email='+email+"&text="+text;
        }
    </script>
</head>
<body>

<div class="container">
	<div class="row">
		<div class="col-xs-12 col-sm-12">
			<p class="userhead" >View AMC'S</p>
		</div>
	</div>
	<div class="row">
		<?php for ($i=0; $i <sizeof($message->funds) ; $i++) {  ?>
			<div class="col-xs-12 col-sm-4 col-md-3">
			<div class="card">
			  <img src="<?= Yii::$app->request->baseUrl ?>/img/NIT.jpeg" alt="Avatar" style="width:100%;height: 210px;">

			  <div class="contain" onclick="go_to_growth(this.id)" style="cursor:pointer" id='<?php echo $i; ?>'>
			    <h4><b><?= Html::encode($message->Amcs) ?></b></h4> 
			    <p id="fund<?php echo $i; ?>"><?= Html::encode($message->funds[$i]) ?></p> 
			  </div>
			</div>
		</div>

	       
		<?php }  ?>
	</div>
	
</div>	
</div>
</body>
</html>