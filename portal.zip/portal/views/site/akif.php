<!DOCTYPE html>
<html>
<head>
	<?php use yii\helpers\Html;
	
  ?>
	<meta charset="utf-8">
	  <meta name="viewport" content="width=device-width, initial-scale=1">
	  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
	  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	  <style type="text/css">
	  	.userhead
	  	{
	  		font-size: 50px;
	  		font-family: bold;
	  		color: grey;

	  	}
	  	.textboxstyle
	  	{
	  		border-radius: 10px;
	  		width: 50%;
	  		margin-bottom: 5px;
	  		
	  	}
	  </style>
	  <script type="text/javascript">
	  	function check(period)
	  	{
	  		
	  		
	  		if (period=="fund manager") {
	  			//alert("investor");
	  			var div1=document.createElement("DIV");
	  			var div2=document.createElement("DIV");
	  			var classname="row";
	  			var classname2="col-xs-12 col-sm-12";
	  			var att = document.createAttribute("class");
	  			att.value=classname;
	  			var att2 = document.createAttribute("class");
	  			att2.value=classname2;
	  			div1.setAttributeNode(att);
	  			div2.setAttributeNode(att2);  	
	  			//div2.innerHTML="investor";
	  			var inputtag=document.createElement("INPUT");
	  			var att_type = document.createAttribute("type");
	  			att_type.value="text";
	  			var att_class = document.createAttribute("class");
	  			att_class.value="textboxstyle";
	  			var att_name = document.createAttribute("name");
	  			att_name.value="amc";
	  			var att_placeholder = document.createAttribute("placeholder");
	  			att_placeholder.value="AMC";
	  			inputtag.setAttributeNode(att_type);
	  			inputtag.setAttributeNode(att_name);
	  			inputtag.setAttributeNode(att_class);
	  			inputtag.setAttributeNode(att_placeholder);
	  			div2.appendChild(inputtag);
	  			div1.appendChild(div2);
	  			var element = document.getElementById("contain");
	  			element.appendChild(div1);
	  			var div_row=document.createElement("DIV");
	  			var div_col=document.createElement("DIV");
	  			var class_row=document.createAttribute("class");
	  			var class_col=document.createAttribute("class");
	  			class_row.value="row";
	  			class_col.value="col-xs-12 col-sm-12";
	  			div_row.setAttributeNode(class_row);
	  			div_col.setAttributeNode(class_col);
	  			var btn=document.createElement("BUTTON");
	  			var att_btn_class=document.createAttribute("class");
	  			att_btn_class.value="btn-success";
	  			btn.setAttributeNode(att_btn_class);
	  			btn.innerHTML="ADD";
	  			div_col.appendChild(btn);
	  			div_row.appendChild(div_col);
	  			var element2 = document.getElementById("contain");
	  			element2.appendChild(div_row);
	  			document.getElementById("usertype").disabled=true;




	  		}
	  		if (period=="investor") {

	  			var div_row=document.createElement("DIV");
	  			var div_col=document.createElement("DIV");
	  			var class_row=document.createAttribute("class");
	  			var class_col=document.createAttribute("class");
	  			class_row.value="row";
	  			class_col.value="col-xs-12 col-sm-12";
	  			div_row.setAttributeNode(class_row);
	  			div_col.setAttributeNode(class_col);
	  			var btn=document.createElement("BUTTON");
	  			var att_btn_class=document.createAttribute("class");
	  			att_btn_class.value="btn-success";
	  			btn.setAttributeNode(att_btn_class);
	  			btn.innerHTML="ADD";
	  			div_col.appendChild(btn);
	  			div_row.appendChild(div_col);
	  			var element = document.getElementById("contain");
	  			element.appendChild(div_row);
	  			document.getElementById("usertype").disabled=true;
	  		}
	  		
	  	}
	  </script>
</head>
<body>
<div class="container" id="contain">
	<div class="row">
		<div class="col-xs-12 col-sm-12">
			<p class="userhead">ADD USER</p>
		</div>
	</div>
	<div calss="row">
		<div calss="col-xs-12 col-sm-12">
			<input type="text" name="name" class="textboxstyle" placeholder="Name">
		</div>
	</div>
	<div class="row">
		<div class="col-xs-12 col-sm-12"><input type="text" name="cnic" class="textboxstyle" placeholder="CNIC"></div>
	</div>
	<div class="row">
		<div class="col-xs-12 col-sm-12">
			<input type="text" name="email" class="textboxstyle" placeholder="Email">
		</div>
	</div>
	<div class="row">
		<div class="col-xs-12 col-sm-12">
			<select name="usertype" onchange="check(this.value)" id="usertype">
				<option value=""></option>
				<option value="investor" >Investor</option>
				<option value="fund manager" >Fund manager</option>

			</select>
		</div>
	</div>

	
</div>
</body>
</html>