
<!DOCTYPE html>
<html>
<head>
	<?php use yii\helpers\Html;
	
  ?>
	<meta charset="utf-8">
	  <meta name="viewport" content="width=device-width, initial-scale=1">
	  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
	  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	  <style type="text/css">
	  	.userhead
	  	{
	  		font-size: 50px;
	  		font-family: bold;
	  		color: grey;

	  	}
	  	.textboxstyle
	  	{
	  		border-radius: 10px;
	  		width: 50%;
	  		
	  	}
	  </style>
	  <script type="text/javascript">
	  	function check(period)
	  	{
	  		
	  		
	  		if (period=="fund manager") {
	  			//alert("investor");
	  			var div1=document.createElement("DIV");
	  			var div2=document.createElement("DIV");
	  			var classname="row";
	  			var classname2="col-xs-12 col-sm-12";
	  			var att = document.createAttribute("class");
	  			att.value=classname;
	  			var att2 = document.createAttribute("class");
	  			att2.value=classname2;
	  			div1.setAttributeNode(att);
	  			div2.setAttributeNode(att2);  	
	  			div2.innerHTML="investor";
	  			div1.appendChild(div2);
	  			var element = document.getElementById("contain");
	  			element.appendChild(div1);
	  		}
	  		if (period=="investor") {
	  			//alert("fund manager");
	  			var div1=document.createElement("DIV");
	  			var div2=document.createElement("DIV");
	  			var classname="row";
	  			var classname2="col-xs-12 col-sm-12";
	  			var att = document.createAttribute("class");
	  			att.value=classname;
	  			var att2 = document.createAttribute("class");
	  			att2.value=classname2;
	  			div1.setAttributeNode(att);
	  			div2.setAttributeNode(att2);  	
	  			div2.innerHTML="manager";
	  			div1.appendChild(div2);
	  			var element = document.getElementById("contain");
	  			element.appendChild(div1);
	  		}
	  	}
	  </script>
</head>
<body>
<div class="container" id="contain">
	<div class="row">
		<div class="col-xs-12 col-sm-12">
			<p class="userhead">ADD USER</p>
		</div>
	</div>
	<div calss="row">
		<div calss="col-xs-12 col-sm-12">
			<input type="text" name="name" class="textboxstyle" placeholder="Name">
		</div>
	</div>
	<div class="row">
		<div class="col-xs-12 col-sm-12"><input type="text" name="cnic" class="textboxstyle" placeholder="CNIC"></div>
	</div>
	<div class="row">
		<div class="col-xs-12 col-sm-12">
			<input type="text" name="email" class="textboxstyle" placeholder="Email">
		</div>
	</div>
	<div class="row">
		<div class="col-xs-12 col-sm-12">
			<select name="usertype" onchange="check(this.value)">
				<option value="investor" >Investor</option>
				<option value="fund manager" >Fund manager</option>

			</select>
		</div>
	</div>
	
</div>
</body>
</html>