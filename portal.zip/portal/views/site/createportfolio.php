<!DOCTYPE html>
<html>
<head>
	<?php use yii\helpers\Html;
	use yii\helpers\Url;
	
  ?>
<meta char
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<style type="text/css">
  .text
  {
    font-size: 20px;
    color: black;
    cursor:pointer;
  }
  .userhead
	  	{
	  		font-size: 50px;
	  		font-family: bold;
	  		color: grey;


	  	}
button.accordion {
    background-color: white;
    color: #444;
    cursor: pointer;
    padding: 18px;
    width: 100%;
    border: none;
    text-align: left;
    outline: none;
    font-size: 20px;
    transition: 0.4s;
}

button.accordion.active, button.accordion:hover {
    background-color: #ccc; 
}

div.panel {
    padding: 0 18px;
    display: none;
    background-color: white;
}

</style>
<script type="text/javascript">

</script> 
</head>
<body>

<div class="container">






	<div class="row">
		<div class="col-xs-12 col-sm-12">
			<h2 class="userhead">Create Portfolio</h2>
		</div>
	</div>

<div class="row">
	<div class="col-xs-12 col-sm-12">
		<button class="accordion">Meezan</button>
<div class="panel">

<ul>
	<li>
		<div class="checkbox">
	      <input type="checkbox" value="Al Meezan Mutual Fund IEQ" id="meezan1" onclick="check(this.value,this.id)"><p onclick="show(this.innerHTML)" style="cursor: pointer;">Al Meezan Mutual Fund IEQ</p>
	    </div>
	</li>


<li>
		<div class="checkbox">
      <input type="checkbox" value="Al Meezan Cash Fund IMM" id="meezan2" onclick="check(this.value,this.id)"><p onclick="show(this.innerHTML)" style="cursor: pointer;">Al Meezan Cash Fund IMM</p>
    </div>
	</li>


<li>
		<div class="checkbox">
      <input type="checkbox" value="Al Meezan Islamic Fund IEQ" id="meezan3" onclick="check(this.value,this.id)"><p onclick="show(this.innerHTML)" style="cursor: pointer;">Al Meezan Islamic Fund IEQ</p>
    </div>
	</li>  
</ul>
</div>
	</div>
</div>


<div class="row">
	<div class="col-xs-12 col-sm-12">
		<button class="accordion">NIT</button>
<div class="panel">
<ul>

<li>
		<div class="checkbox">
      <input type="checkbox" value="NI(U)T EQ" id="NIT1" onclick="check(this.value,this.id)"><p onclick="show(this.innerHTML)" style="cursor: pointer;">NI(U)T EQ</p>
    </div>
	</li>





<li>
		<div class="checkbox">
      <input type="checkbox" value="NIT Islamic Equity IEQ" id="NIT2" onclick="check(this.value,this.id)"><p onclick="show(this.innerHTML)" style="cursor: pointer;">NIT Islamic Equity IEQ</p>
    </div>
	</li>




<li>
		<div class="checkbox">
      <input type="checkbox" value="NIT GTF MM" id="NIT3" onclick="check(this.value,this.id)"><p onclick="show(this.innerHTML)" style="cursor: pointer;">NIT GTF MM</p>
    </div>
	</li>

</ul>
</div>
	</div>
</div>



<div class="row">
	<div class="col-xs-12 col-sm-12">
		<button class="accordion">NBP Fullerton</button>
<div class="panel">
<ul>

<li>
		<div class="checkbox">
      <input type="checkbox" value="NAFA Islamic Stock IEQ" id="NAFA1" onclick="check(this.value,this.id)"><p onclick="show(this.innerHTML)" style="cursor: pointer;">NAFA Islamic Stock IEQ</p>
    </div>
	</li>




	<li>
		<div class="checkbox">
      <input type="checkbox" value="NAFA Moneymarket MM" id="NAFA2" onclick="check(this.value,this.id)"><p onclick="show(this.innerHTML)" style="cursor: pointer;">NAFA Moneymarket MM<</p>
    </div>
	</li>




	<li>
		<div class="checkbox">
      <input type="checkbox" value="NAFA Stock Fund EQ" id="NAFA3" onclick="check(this.value,this.id)"><p onclick="show(this.innerHTML)" style="cursor: pointer;">NAFA Stock Fund EQ</p>
    </div>
	</li>





 
</ul>
</div>
	</div>
	
</div>

<div class="row">
	<div class="col-xs-12 col-sm-12">
		<button class="accordion">UBL</button>
<div class="panel">
<ul>
	<li>
		<div class="checkbox">
      <input type="checkbox" value="Al Ameen Islamic Cash fund IMM" id="UBL1" onclick="check(this.value,this.id)"><p onclick="show(this.innerHTML)" style="cursor: pointer;">Al Ameen Islamic Cash fund IMM</p>
    </div>
	</li>

	<li>
		<div class="checkbox">
      <input type="checkbox" value="Al Ameen Islamic Dediicated Equity IEQ" id="UBL2" onclick="check(this.value,this.id)"><p onclick="show(this.innerHTML)" style="cursor: pointer;">Al Ameen Islamic Dediicated Equity IEQ</p>
    </div>
	</li>

	<li>
		<div class="checkbox">
      <input type="checkbox" value="UBL Stock Advantage EQ" id="UBL3" onclick="check(this.value,this.id)"><p onclick="show(this.innerHTML)" style="cursor: pointer;">UBL Stock Advantage EQ</p>
    </div>
	</li>

</ul>
</div>
	</div>
</div>


<div class="row">
	<div class="col-xs-12 col-sm-12">
		<button class="accordion">HBL</button>
<div class="panel">
<ul>
	<li>
		<div class="checkbox">
      <input type="checkbox" value="HBL Cash Fund MM" id="HBL1" onclick="check(this.value,this.id)"><p onclick="show(this.innerHTML)" style="cursor: pointer;">HBL Cash Fund MM</p>
    </div>
	</li>

	<li>
		<div class="checkbox">
      <input type="checkbox" value="HBL Moneymarket Fund MM" id="HBL2" onclick="check(this.value,this.id)"><p onclick="show(this.innerHTML)" style="cursor: pointer;">HBL Moneymarket Fund MM</p>
    </div>
	</li>

	<li>
		<div class="checkbox">
      <input type="checkbox" value="HBL Islamic Equity Fund IEQ" id="HBL3" onclick="check(this.value,this.id)"><p onclick="show(this.innerHTML)" style="cursor: pointer;">HBL Islamic Equity Fund IEQ</p>
    </div>
	</li>
</ul>
</div>
	</div>
</div>


<div class="row">
	<div class="col-xs-12 col-sm-12">
		<button class="accordion">arif habib</button>
<div class="panel">
<ul>


	<li>
		<div class="checkbox">
      <input type="checkbox" value="MCB Cash Management Optimizer MM" id="ARIF1" onclick="check(this.value,this.id)"><p onclick="show(this.innerHTML)" style="cursor: pointer;">MCB Cash Management Optimizer MM</p>
    </div>
	</li>



	<li>
		<div class="checkbox">
      <input type="checkbox" value="MCB Pakistan Stock Market Fund EQ" id="ARIF2" onclick="check(this.value,this.id)"><p onclick="show(this.innerHTML)" style="cursor: pointer;">MCB Pakistan Stock Market Fund EQ</p>
    </div>
	</li>




	<li>
		<div class="checkbox">
      <input type="checkbox" value="Al Hamra Islamic Stock Fund IEQ" id="ARIF3" onclick="check(this.value,this.id)"><p onclick="show(this.innerHTML)" style="cursor: pointer;">Al Hamra Islamic Stock Fund IEQ</p>
    </div>
	</li>
</ul>
</div>
	</div>
</div>




<div class="row">
	<div class="col-xs-12 col-sm-12">
		<button class="accordion">ABL</button>
<div class="panel">
<ul>
<li>
		<div class="checkbox">
      <input type="checkbox" value="ABL Cash Fund MM" id="ABL1" onclick="check(this.value,this.id)"><p onclick="show(this.innerHTML)" style="cursor: pointer;">ABL Cash Fund MM</p>
    </div>
	</li>


	<li>
		<div class="checkbox">
      <input type="checkbox" value="ABL Stock Fund EQ" id="ABL2" onclick="check(this.value,this.id)"><p onclick="show(this.innerHTML)" style="cursor: pointer;">ABL Stock Fund EQ</p>
    </div>
	</li>


	<li>
		<div class="checkbox">
      <input type="checkbox" value="ABL Islamic Stock IEQ" id="ABL3" onclick="check(this.value,this.id)"><p onclick="show(this.innerHTML)" style="cursor: pointer;">ABL Islamic Stock IEQ</p>
    </div>
	</li>
</ul>
</div>
	</div>
</div>


<div class="row">
	<div class="col-xs-12 col-sm-12">
		<button class="accordion">Al Falah GHP</button>
<div class="panel">
<ul>
	<li>
		<div class="checkbox">
      <input type="checkbox" value="Stock Fund EQ" id="AL1" onclick="check(this.value,this.id)"><p onclick="show(this.innerHTML)" style="cursor: pointer;">Stock Fund EQ</p>
    </div>
	</li>
	<li>
		<div class="checkbox">
      <input type="checkbox" value="Moneymarket Fund MM" id="AL2" onclick="check(this.value,this.id)"><p onclick="show(this.innerHTML)" style="cursor: pointer;">Moneymarket Fund MM</p>
    </div>
	</li>
	<li>
		<div class="checkbox">
      <input type="checkbox" value="Alpha fund EQ" id="AL3" onclick="check(this.value,this.id)"><p onclick="show(this.innerHTML)" style="cursor: pointer;">Alpha fund EQ</p>
    </div>
	</li>
</ul>
</div>
	</div>
</div>



<div class="row">
	<div class="col-xs-12 col-sm-12">
		<button class="accordion">Atlas</button>
<div class="panel">
<ul>

<li>
		<div class="checkbox">
      <input type="checkbox" value="Atlas Islamic Stock Fund IEQ" id="AT1" onclick="check(this.value,this.id)"><p onclick="show(this.innerHTML)" style="cursor: pointer;">Atlas Islamic Stock Fund IEQ</p>
    </div>
	</li>

	<li>
		<div class="checkbox">
      <input type="checkbox" value="Atlas Money Market Fund MM" id="AT2" onclick="check(this.value,this.id)"><p onclick="show(this.innerHTML)" style="cursor: pointer;">Atlas Money Market Fund MM</p>
    </div>
	</li>

	<li>
		<div class="checkbox">
      <input type="checkbox" value="Atlas Stock Market fund IEQ" id="AT3" onclick="check(this.value,this.id)"><p onclick="show(this.innerHTML)" style="cursor: pointer;">Atlas Stock Market fund IEQ</p>
    </div>
	</li>

</ul>
</div>
	</div>
</div>
	<div class="row">
		<div class="col-xs-12 col-sm-12">
			<button class="btn-success" style="margin-left: 40%;,margin-right: 60%;" onclick="Create()">Create</button>
		</div>
	</div>
</div>




<script>
var acc = document.getElementsByClassName("accordion");
var i;
var funds=new Array();
var count=0;

for (i = 0; i < acc.length; i++) {
    acc[i].onclick = function(){
        this.classList.toggle("active");
        var panel = this.nextElementSibling;
        if (panel.style.display === "block") {
            panel.style.display = "none";
        } else {
            panel.style.display = "block";
        }
    }
}
function show(x)
{
	var email="<?= Html::encode($obj->email) ?>";
	alert(email);
	//window.location.href= 'index.php?r=site%2Ffunddetail&email='+email;
}
function check(y,z)
{
	var checkbox=document.getElementById(z);
	if (checkbox.checked) {
		funds[count]=y;
		count++;

		
	}
	else
	{
	const index = funds.indexOf(y);
    funds.splice(index, 1);
	}
}
function Create()
{
	window.location.href= 'index.php?r=site%2Fshowportfolio&funds='+funds;
}
</script>

</body>
</html>