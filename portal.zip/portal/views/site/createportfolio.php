<!DOCTYPE html>
<html>
<head>
	<?php use yii\helpers\Html;
	use yii\helpers\Url;
	
  ?>
<meta char
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link href="http://cdn-na.infragistics.com/igniteui/2017.2/latest/css/themes/infragistics/infragistics.theme.css" rel="stylesheet" />
    <link href="http://cdn-na.infragistics.com/igniteui/2017.2/latest/css/structure/infragistics.css" rel="stylesheet" />

    <script src="http://ajax.aspnetcdn.com/ajax/modernizr/modernizr-2.8.3.js"></script>
    <script src="http://code.jquery.com/jquery-1.11.3.min.js"></script>
    <script src="http://code.jquery.com/ui/1.11.1/jquery-ui.min.js"></script>

    <!-- Ignite UI Required Combined JavaScript Files -->
    <script src="http://cdn-na.infragistics.com/igniteui/2017.2/latest/js/infragistics.core.js"></script>
    <script src="http://cdn-na.infragistics.com/igniteui/2017.2/latest/js/infragistics.lob.js"></script>
<style type="text/css">
  .text
  {
    font-size: 20px;
    color: black;
    cursor:pointer;
  }
  .userhead
	  	{
	  		font-size: 50px;
	  		font-family: bold;
	  		color: grey;


	  	}
button.accordion {
    background-color: white;
    color: #444;
    cursor: pointer;
    padding: 18px;
    width: 100%;
    border: none;
    text-align: left;
    outline: none;
    font-size: 20px;
    transition: 0.4s;
}

button.accordion.active, button.accordion:hover {
    background-color: #ccc; 
}

div.panel {
    padding: 0 18px;
    display: none;
    background-color: white;
}
.iframe2{
	border: 1px solid black;
	width: 300px;
	height: 300px;
	margin-left: 470px;
}


body,html{ height: 100%; margin:0; padding:0; }

</style>
<script type="text/javascript">

</script> 
</head>
<body>

<div class="container">






	<div class="row">
		<div class="col-xs-12 col-sm-12">
			<h2 class="userhead">Create Portfolio</h2>
		</div>
	</div>
	<div class="row">
		<div class="col-xs-6 col-sm-6 col-md-6">
			<div class="row">
	<div class="col-xs-12 col-sm-12">
		<button class="accordion">Meezan</button>
<div class="panel">

<ul>
	<li>
		<div class="checkbox">
	      <input type="checkbox" value="Al Meezan mutual fund" id="meezan1" onclick="check(this.value,this.id)"><p onclick="show(this.innerHTML)" style="cursor: pointer;">Al Meezan mutual fund</p>
	    </div>
	</li>





<li>
		<div class="checkbox">
      <input type="checkbox" value="Al Meezan Islamic Fund" id="meezan3" onclick="check(this.value,this.id)"><p onclick="show(this.innerHTML)" style="cursor: pointer;">Al Meezan Islamic Fund</p>
    </div>
	</li>  
</ul>
</div>
	</div>
</div>




<div class="row">
	<div class="col-xs-12 col-sm-12">
		<button class="accordion">NBP Fullerton</button>
<div class="panel">
<ul>






	<li>
		<div class="checkbox">
      <input type="checkbox" value="NAFA Stock Fund" id="NAFA3" onclick="check(this.value,this.id)"><p onclick="show(this.innerHTML)" style="cursor: pointer;">NAFA Stock Fund</p>
    </div>
	</li>





 
</ul>
</div>
	</div>
	
</div>




<div class="row">
	<div class="col-xs-12 col-sm-12">
		<button class="accordion">UBL</button>
<div class="panel">
<ul>
	

	<li>
		<div class="checkbox">
      <input type="checkbox" value="UBL Stock Advantage" id="UBL3" onclick="check(this.value,this.id)"><p onclick="show(this.innerHTML)" style="cursor: pointer;">UBL Stock Advantage</p>
    </div>
	</li>

</ul>
</div>
	</div>
</div>



<div class="row">
	<div class="col-xs-12 col-sm-12">
		<button class="accordion">arif habib</button>
<div class="panel">
<ul>


	



	<li>
		<div class="checkbox">
      <input type="checkbox" value="MCB Pakistan Stock Market" id="ARIF2" onclick="check(this.value,this.id)"><p onclick="show(this.innerHTML)" style="cursor: pointer;">MCB Pakistan Stock Market</p>
    </div>
	</li>




	
</ul>
</div>
	</div>
</div>





<div class="row">
	<div class="col-xs-12 col-sm-12">
		<button class="accordion">Al Falah GHP</button>
<div class="panel">
<ul>
	<li>
		<div class="checkbox">
      <input type="checkbox" value="AL Falah Stock fund" id="AL1" onclick="check(this.value,this.id)"><p onclick="show(this.innerHTML)" style="cursor: pointer;">AL Falah Stock fund</p>
    </div>
	</li>
	
	<li>
		<div class="checkbox">
      <input type="checkbox" value="AL Falah Alpha fund" id="AL3" onclick="check(this.value,this.id)"><p onclick="show(this.innerHTML)" style="cursor: pointer;">AL Falah Alpha fund</p>
    </div>
	</li>
</ul>
</div>
	</div>
</div>



<div class="row">
	<div class="col-xs-12 col-sm-12">
		<button class="accordion">Atlas</button>
<div class="panel">
<ul>

<li>
		<div class="checkbox">
      <input type="checkbox" value="Atlas Islamic Fund" id="AT1" onclick="check(this.value,this.id)"><p onclick="show(this.innerHTML)" style="cursor: pointer;">Atlas Islamic Fund</p>
    </div>
	</li>

	

	<li>
		<div class="checkbox">
      <input type="checkbox" value="Atlas Stock Market" id="AT3" onclick="check(this.value,this.id)"><p onclick="show(this.innerHTML)" style="cursor: pointer;">Atlas Stock Market</p>
    </div>
	</li>

</ul>
</div>
	</div>
</div>
<div class="row">
		<div class="col-xs-12 col-sm-12">
			<button class="btn-success" style="margin-left: 40%;,margin-right: 60%;width: 100px;height: 50px;border-radius: 10px;" onclick="Create()">Create</button>
		</div>
	</div>
	


</div>
<div class="col-xs-6 col-sm-6 col-md-6 ">
			<div id="dialog" style="display:none; border:15px solid lightgrey;height: 450px;width: 100%;background-color: black;">
        <iframe src="" frameborder="0" style="height: 100%;width: 100%;display: block;" id="iframe_id"></iframe>
		</div>

		</div>

		

	</div>
	
	</div>


























	



<script>
var acc = document.getElementsByClassName("accordion");
var i;
var funds=new Array();
var count=0;

for (i = 0; i < acc.length; i++) {
    acc[i].onclick = function(){
        this.classList.toggle("active");
        var panel = this.nextElementSibling;
        if (panel.style.display === "block") {
            panel.style.display = "none";
        } else {
            panel.style.display = "block";
        }
    }
}
function show(x)
{
	var email="<?= Html::encode($obj->email) ?>";
	//alert(x);
	document.getElementById('dialog').style.display = "block";
	document.getElementById('iframe_id').src='index.php?r=site%2Ffunddetail&email='+email+"&text="+x;
	//alert(x);
	//var x=
	//window.location.href= 'index.php?r=site%2Ffunddetail&email='+email;
}

function check(y,z)
{
	var checkbox=document.getElementById(z);
	if (checkbox.checked) {
		funds[count]=y;
		count++;

		
	}
	else
	{
	const index = funds.indexOf(y);
    funds.splice(index, 1);
    count--;
	}
}
function Create()
{
	var email="<?= Html::encode($obj->email) ?>";
	//alert(funds.length)
	if (funds.length==0) {
		alert("select funds");
	}
	else
	{
		window.location.href= 'index.php?r=site%2Fshowportfolio&funds='+funds+"&email="+email;
	}
	
}






</script>

</body>
</html>