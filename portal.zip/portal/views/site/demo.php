<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<?php use yii\helpers\Html;  ?>
<div style="background-color: grey;">
	 <?= Html::encode($message->name) ?>
	 <?= Html::encode($message->email) ?>
	 <?= Html::encode($message->subject) ?>
	 <?= Html::encode($message->body) ?>

</div>
</body>
</html>