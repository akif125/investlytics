<!DOCTYPE html>
<html>
<head>
	<title>
		<?php use yii\helpers\Html;
  use yii\helpers\Url;
  
  ?>
<meta charset="utf-8">

  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

	</title>
</head>
<body>
<div class="container">
	<div class="row">
		<div class="col-xs-12 col-sm-12">
			<h3><b>Fund:</b><?= Html::encode($obj6->fund) ?></h3>

		</div>
		
</div>
<div class="row">
		<div class="col-xs-12 col-sm-12">
			<h3><b>Unit:</b><?= Html::encode($obj6->unit) ?></h3>
			
		</div>
	</div>


	<table class="table table-striped">
    <thead>
      <tr>
        <th>#</th>
        <th>Date</th>
        <th>NAV</th>
        

      </tr>
    </thead>
    <tbody>
        <?php for ($i=0; $i <sizeof($obj6->date) ; $i++) {  ?>
                  <tr>
                    <td><?= $i+1 ?></td>
                  <td id="unit-<?php echo $i; ?>"><?= Html::encode($obj6->date[$i]) ?></td>
                  <td id="date-<?php echo $i; ?>"><?= Html::encode($obj6->gain[$i]) ?></td>
                </tr>
             
        <?php }  ?>
        
      
      
    </tbody>
  </table>
</div>
</body>
</html>