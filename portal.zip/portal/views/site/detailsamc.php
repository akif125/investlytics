<!DOCTYPE html>
<html>
<head>
	<?php use yii\helpers\Html;
	use yii\helpers\Url;
	
  ?>
	<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <script type="text/javascript">
  	function render_page()
	{
		var email="<?= Html::encode($obj->email) ?>";
		//alert(email);
		window.location.href= 'index.php?r=site%2Ffunddetail&email='+email;
	}
  </script>
</head>
<body>
<div class="container">
	<div class="row">
		<div class="col-xs-6 col-sm-6 col-md-6">
			<p><span>FUND MANAGER NAME:</span>Manager1</p>
		</div>
		<div class="col-xs-6 col-sm-6 col-md-6">
			<div style="border: 1px solid black;height: 200px ">The graph of the growth of fund will be shown here</div>
		</div>
	</div>
	<div class="row">
		<div class="col-xs-12 col-sm-12"><button class="btn-success" onclick="render_page()">Show full growth</button></div>
	</div>
</div>
</body>
</html>