<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>
  <script type="text/javascript">
  window.onload = function () {

var chart = new CanvasJS.Chart("chartContainer", {
	theme: "light2", // "light1", "light2", "dark1", "dark2"
	animationEnabled: true,
	title:{
		text: "FUND1 Values"   
	},
	axisX: {
		interval: 1,
		intervalType: "month",
		valueFormatString: "MMM"
	},
	axisY:{
		title: "Price (in PKR)",
		valueFormatString: "PKR#0"
	},
	data: [{        
		type: "line",
		markerSize: 12,
		xValueFormatString: "MMM, YYYY",
		yValueFormatString: "PKR###.#",
		dataPoints: [        
			{ x: new Date(2016, 00, 1), y: 61, indexLabel: "", markerType: "circle",  markerColor: "#6B8E23" ,lineColor: "Black"},
			{ x: new Date(2016, 01, 1), y: 71, indexLabel: "", markerType: "circle",  markerColor: "#6B8E23" ,lineColor: "Black"},
			{ x: new Date(2016, 02, 1) , y: 55, indexLabel: "", markerType: "circle", markerColor: "tomato" ,lineColor: "Black"},
			{ x: new Date(2016, 03, 1) , y: 50, indexLabel: "", markerType: "circle", markerColor: "tomato" ,lineColor: "Black"},
			{ x: new Date(2016, 04, 1) , y: 65, indexLabel: "", markerType: "circle", markerColor: "#6B8E23" ,lineColor: "Black"},
			{ x: new Date(2016, 05, 1) , y: 85, indexLabel: "", markerType: "circle", markerColor: "#6B8E23" ,lineColor: "Black"},
			{ x: new Date(2016, 06, 1) , y: 68, indexLabel: "", markerType: "circle", markerColor: "tomato" ,lineColor: "Black"},
			{ x: new Date(2016, 07, 1) , y: 28, indexLabel: "", markerType: "circle", markerColor: "tomato" ,lineColor: "Black"},
			{ x: new Date(2016, 08, 1) , y: 34, indexLabel: "", markerType: "circle", markerColor: "#6B8E23" ,lineColor: "Black"},
			{ x: new Date(2016, 09, 1) , y: 24, indexLabel: "", markerType: "circle", markerColor: "tomato" ,lineColor: "Black"},
			{ x: new Date(2016, 10, 1) , y: 44, indexLabel: "", markerType: "circle", markerColor: "#6B8E23",lineColor: "Orange" },
			{ x: new Date(2016, 11, 1) , y: 34, indexLabel: "Predicted", markerType: "cross", markerColor: "tomato" }
		]
	}]
});
chart.render();

}
</script>
</head>
<body>
<div calss="container">
	
	<div class="row">
		<div class="col-xs-12 col-sm-12">
			<div id="chartContainer" style="border: 1px solid black;height: 400px; "></div>
			
		</div>
	</div>
	<br>
	<div class="row">
		<table class="table table-striped">
			<thead>
				<tr>
			        
			        <th style="font-family: bold;font-size: 20px;">Fund Detail</th>
			        <tbody>
		        		<tr>
	                    <td>Fund  Name</td>
	                    <td>NIUT</td>
	                	</tr>
	                	<tr>
	                		<td>Fund manager name</td>
	                    <td>Manzoor Ahmed</td>
	                	</tr>
	                	<tr>
	                		<td>Securities</td>
	                    <td>NA</td>
	                	</tr>
	                	<tr>
	                		<td>NAV</td>
	                    <td>44</td>
	                	</tr>
	                	<tr>
	                		<td>NAV per unit</td>
	                    <td>71.46mn</td>
	                	</tr>
	                	<tr>
	                		<td>Risk factor</td>
	                    <td>Moderate / High</td>
	                	</tr>
	                	<tr>
	                		<td>Category</td>
	                    <td>Equity</td>
	                	</tr>
			        </tbody>
			        

		      </tr>
			</thead>
		</table>
		
	</div>
</div>
</body>
</html>