<!DOCTYPE html>
<html>
<head>
	<?php use yii\helpers\Html;
	use yii\helpers\Url;
	
  ?>
	<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>
  <script type="text/javascript">
  window.onload = function () {
  	var test = new Array();
  	var date;
  	//var value=new Array();
	//test=new Date(date)
  	<?php for ($i=0; $i <sizeof($obj->nav) ; $i++) {  ?>
  		date='<?= Html::encode($obj->date[$i]) ?>'
  		//value[<?php echo $i; ?>]='<?= Html::encode($obj->nav[$i]) ?>'
  		test[<?php echo $i; ?>]=new Date(date);
  		
		
	       
		<?php }  ?>
		
		//var g=value[0];
		
		//alert(g);

			var chart = new CanvasJS.Chart("chartContainer", {
			
				theme: "light2", // "light1", "light2", "dark1", "dark2"
	animationEnabled: true,
	title:{
		text: "Growth"   
	},
	axisX: {
		interval: 1,
		intervalType: "month",
		valueFormatString: "MMM-YY"
	},
	axisY:{
		title: "Price (in PKR)",
		valueFormatString: "PKR#0"
	},
	data: [{        
		type: "line",
		markerSize: 12,
		xValueFormatString: "DD-MMM-YYY",
		yValueFormatString: "PKR###.#",
		dataPoints: [
		
		        <?php for ($i=0; $i <sizeof($obj->nav)-1 ; $i++) {  ?>
		        	<?php
		        		$x=$obj->sent[$i];
		        	?>
		        	{ x: test[<?php echo $i; ?>], y:<?php echo $obj->nav[$i];?>, indexLabel:'<?php echo $x  ?>', markerType: "circle",  markerColor: "#6B8E23" ,lineColor: "Black"},
			<?php }  ?>
			{ x: test[<?php echo $i; ?>], y:<?php echo $obj->nav[sizeof($obj->nav)-1];?>, indexLabel: "Predicted", markerType: "cross",  markerColor: "#0000FF" ,lineColor: "black"}

		]
	}]
			
	
});

		
  	
  	
		//var test2=new Date(date2)

chart.render();

}
</script>
</head>
<body>
<div calss="container">
	
	<div class="row table-responsive">
		<div class="col-xs-12 col-sm-12">
			<div id="chartContainer" style="border: 1px solid black;height: 400px; width: 5000px;"></div>
			
		</div>
	</div>
	<br>
	<div class="row">
		<table class="table table-striped">
			<thead>
				<tr>
			        
			        <th style="font-family: bold;font-size: 20px;">Fund Detail</th>
			        <tbody>
		        		<tr>
	                    <td>Fund  Name</td>
	                    <td><?= Html::encode($obj->fundname) ?></td>
	                	</tr>
	                	<tr>
	                		<td>Fund manager name</td>
	                    <td><?= Html::encode($obj->fundmanager) ?></td>
	                	</tr>
	                	<tr>
	                		<td>Found Date</td>
	                    <td><?= Html::encode($obj->founddate) ?></td>
	                	</tr>
	                	<tr>
	                		<td>NAV</td>
	                    <td><?= Html::encode($obj->nav[sizeof($obj->nav)-1]) ?></td>
	                	</tr>
	                	<tr>
	                		<td>NAV per unit</td>
	                    <td>71.46mn</td>
	                	</tr>
	                	<tr>
	                		<td>Risk factor</td>
	                    <td><?= Html::encode($obj->risk) ?></td>
	                	</tr>
	                	<tr>
	                		<td>Category</td>
	                    <td><?= Html::encode($obj->category) ?></td>
	                	</tr>
			        </tbody>
			        

		      </tr>
			</thead>
		</table>
		
	</div>
</div>
</body>
</html>