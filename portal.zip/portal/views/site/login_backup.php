<div class="row">
		<div class="col-xs-12 col-sm-12">
			<p class="userhead">Login</p>
		</div>
	</div>
	<div calss="row">
		<div calss="col-xs-12 col-sm-12">
			<input type="text" name="email" id="email" class="textboxstyle" placeholder="Email">
		</div>
	</div>
	<div class="row">
		<div class="col-xs-12 col-sm-12"><input type="text" name="password" id="password" class="textboxstyle" placeholder="Password"></div>
	</div>

	<div class="row">
				
				<div class="col-xs-12 col-sm-12"><button class="btn-success" onkeypress onclick="senddata()" >Login</button></div>
			</div>