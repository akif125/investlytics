<!DOCTYPE html>
<html>
<head>
	<?php use yii\helpers\Html;
	
  ?>
	<meta charset="utf-8">
	  <meta name="viewport" content="width=device-width, initial-scale=1">
	  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
	  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	  <style type="text/css">

	  	.userhead
	  	{
	  		font-size: 50px;
	  		font-family: bold;
	  		color: black;
	  		position: fixed;
			  top: 50%;
			  left: 50%;
			  margin-top: -150px;
			  margin-left: -50px;

	  	}
	  	.textboxstyle
	  	{
	  		border: 0;
		  outline: 0;
		  background: transparent;
		  border-bottom: 1px solid black;

	  		width: 50%;
	  		position: fixed;
			  top: 50%;
			  left: 50%;
			  margin-top: -60px;
			  margin-left: -300px;

	  		
	  	}
	  	.textboxstyle2
	  	{
	  		border: 0;
		  outline: 0;
		  background: transparent;
		  border-bottom: 1px solid black;
	  		width: 50%;
	  		position: fixed;
			  top: 50%;
			  left: 50%;
			  margin-top: -10px;
			  margin-left: -300px;

	  		
	  	}
	  	.btn-success
	  	{
	  		position: fixed;
			  top: 50%;
			  left: 50%;
			  margin-top: 50px;
			  margin-left: -40px;
	  	}
	  	body
	  	{
	  		background-image: url(<?= Yii::$app->request->baseUrl ?>/img/new.png);
	  		background-repeat: no-repeat;
	  		background-size: cover;
	  		background-position: 50% 20%;
	  	}
	  	.center_div
	  	{
	  		background-color: white;
	  		width: 350px;
	  		height: 350px;
	  		
	  		 position: fixed;
			  top: 50%;
			  left: 50%;
			  margin-top: -90px;
			  margin-left: -180px;
			  box-shadow: 0 4px 8px 0 rgba(2,0,0,0.0);
    			transition: 0.3s;
    			border-radius: 7px;
}
	  	
	
	  	
	  </style>
	  <script type="text/javascript">
	  	function senddata()
	  	{
	  		//alert(email +" "+password);
	  		var email_tag=document.getElementById("email");
	  		 var password_tag=document.getElementById("password");
	  		 var email=email_tag.value;
	  		 var password=password_tag.value;
	  		//alert(email.value +" "+password.value);
	  		//window.location.href= 'index.php?r=site%2Fadminhome&email='+email.value+"&password="+password.value;
	  		$.ajax({
                type: "post",
                url: "index.php?r=site%2Flogin2",
                data: {'email' : email,'password': password},
            	dataType: "json",
                success: function (data) {
                	if (data=="admin") {
                		window.location.href= 'index.php?r=site%2Fadminhome';
                	}
                	else if(data=="investor")
                	{
                        var email=document.getElementById("email").value;
                        
                		window.location.href= 'index.php?r=site%2Finvestorhome&email='+email;
                		
                	}
                	else if(data=="fundmanager")
                	{
                		alert("fundmanager");
                		// window.location.href= 'index.php?r=site%2F'
                	}
                	else{
                		alert("incorect email or password");
                	}
            			
                },
                error: function (exception) {
                    alert(JSON.stringify(exception));
                }
            });
	  	}


	  </script>
</head>
<body>

<div class="container" id="contain">
	
		<div class="row">
			<div class="col-xs-12 col-sm-12">
				<p class="userhead">Login</p>
			</div>
		</div>
		<div class="row">
			<div class="col-xs-12 col-sm-12">
				<input type="text" name="email" id="email" class="textboxstyle" placeholder="Email">
			</div>
		</div>
		<div class="row">
			<div class="col-xs-12 col-sm-12"><input type="text" name="password" id="password" class="textboxstyle2" placeholder="Password"></div>
		</div>
		<div class="row">
				
				<div class="col-xs-12 col-sm-12"><button class="btn-success" onkeypress onclick="senddata()" style="margin-top: 40px;width: 90px;height:40px; ">Login</button></div>
			</div>
	
	<!-- <div class="row">
		<div class="col-xs-12 col-sm-12">
			<input type="text" name="email" class="textboxstyle" placeholder="Email">
		</div>
	</div> -->
	<!-- <div class="row">
		<div class="col-xs-12 col-sm-12">
			<select name="usertype" onchange="check(this.value)">
				<option value="investor" >Investor</option>
				<option value="fund manager" >Fund manager</option>

			</select>
		</div>
	</div> -->
	
</div>
</body>
</html>