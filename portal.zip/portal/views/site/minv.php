<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<style type="text/css">
  .text
  {
    font-size: 20px;
    color: black;
    cursor:pointer;
  }
button.accordion {
    background-color: #eee;
    color: #444;
    cursor: pointer;
    padding: 18px;
    width: 100%;
    border: none;
    text-align: left;
    outline: none;
    font-size: 15px;
    transition: 0.4s;
}

button.accordion.active, button.accordion:hover {
    background-color: #ccc; 
}

div.panel {
    padding: 0 18px;
    display: none;
    background-color: white;
}
</style>
<script type="text/javascript">

</script> 
</head>
<body>

<h2>Create Portfolio</h2>

<button class="accordion">AMC1</button>
<div class="panel">

<ul>
  <p><button class="w3-button w3-block w3-White w3-left-align">Fund1</button></p>
  <p><button class="w3-button w3-block w3-White w3-left-align">Fund2</button></p>
  <p><button class="w3-button w3-block w3-White w3-left-align">Fund3</button></p>
</ul>
</div>

<button class="accordion">AMC2</button>
<div class="panel">
<p></p>
</div>

<button class="accordion">AMC3</button>
<div class="panel">
<p></p>
</div>

<script>
var acc = document.getElementsByClassName("accordion");
var i;

for (i = 0; i < acc.length; i++) {
    acc[i].onclick = function(){
        this.classList.toggle("active");
        var panel = this.nextElementSibling;
        if (panel.style.display === "block") {
            panel.style.display = "none";
        } else {
            panel.style.display = "block";
        }
    }
}
</script>

</body>
</html>
