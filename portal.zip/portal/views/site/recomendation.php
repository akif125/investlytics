<!DOCTYPE html>
<html>
<head>
<?php use yii\helpers\Html;
  use yii\helpers\Url;
  
  ?>
<meta charset="utf-8">

  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<style type="text/css">
	.text
	{
		font-size: 20px;
		color: black;
		cursor:pointer;
	}
	button.accordion {
    background-color: white;
    color: #444;
    cursor: pointer;
    padding: 18px;
    width: 100%;
    border: none;
    text-align: left;
    outline: none;
    font-size: 20px;
    transition: 0.4s;
}
.userhead
	  	{
	  		font-size: 50px;
	  		font-family: bold;
	  		color: grey;

	  	}

button.accordion.active, button.accordion:hover {
    background-color: #ccc; 
}

div.panel {
    padding: 0 18px;
    display: none;
    background-color: white;
}
</style>
<script type="text/javascript">
	

	
</script>	
		
</head>
<body>
  <div class="container">
    <div class="row">
      <div class="col-xs-12 col-sm-12">
        <h1 class="userhead">Recomendations</h1>
      </div>
    </div>
  </div>
<table class="table table-striped">
    <thead>
      <tr>
        
        <th>Funds</th>
        <th>NAV</th>
        <th>Predicted NAV</th>

      </tr>
    </thead>
    <tbody>
        <?php for ($i=sizeof($obj->nav)-1; $i >=0 ; $i--) {  ?>
                  <tr>
                    
                    
                  <td><?= Html::encode($obj->funds[$i]) ?></td>

                  <td><?= Html::encode($obj->nav_actual[$i]) ?></td>
                   <?php if($obj->nav_actual[$i]>$obj->nav[$i]){?>
                    <td style="color: red;font-size: 20px"><?= Html::encode($obj->nav[$i]) ?></td>
                     <?php }  ?>
                     <?php if($obj->nav_actual[$i]<$obj->nav[$i]){?>
                    <td style="color: lightgreen;font-size: 20px"><?= Html::encode($obj->nav[$i]) ?></td>
                     <?php }  ?>
                </tr>
             
        <?php }  ?>
        
      
      
    </tbody>
  
</body>
</html>
