<!DOCTYPE html>
<html>
<head>
	<?php use yii\helpers\Html;
	
  ?>
	 <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <style type="text/css">
  .text
  {
    font-size: 20px;
    color: black;
    cursor:pointer;
  }
  .userhead
	  	{
	  		font-size: 50px;
	  		font-family: bold;
	  		color: grey;

	  	}
	  	.textboxstyle
	  	{
	  		border-radius: 10px;
	  		width: 50%;
	  		margin-bottom: 5px;
	  		
	  	}
button.accordion {
    background-color: white;
    color: #444;
    cursor: pointer;
    padding: 18px;
    width: 100%;
    border: none;
    text-align: left;
    outline: none;
    font-size: 20px;
    transition: 0.4s;
}

button.accordion.active, button.accordion:hover {
    background-color: #ccc; 
}

div.panel {
    padding: 0 18px;
    display: none;
    background-color: white;
}
.text
	{
		font-size: 20px;
		color: black;
		cursor:pointer;
	}
</style>
<script type="text/javascript">
	var funds=new Array();
	var units=new Array();
	var fund;
	var unit;
	var count=0;
	function onAdd(id)
	{
		fund_id='fund'+id;
		unit_id='unit'+id;
		//alert(document.getElementById(unit_id).value);
		fund=document.getElementById(fund_id).innerHTML;
		unit=document.getElementById(unit_id).value;
		funds[count]=fund;
		units[count]=unit;
		count++;
		//alert(funds[1]);
		//alert(unit);

	}
	function onAddAll()
	{
		var email2='<?= Html::encode($obj5->email) ?>';
		//var email = email2.substr(1);
		//alert("asd"+email);
		$.ajax({
                type: "post",
                url: "index.php?r=site%2Fsaveinvestment",
                data: {'funds' : funds,'units': units,'email': email2},
            	dataType: "json",
                success: function (data) {
                	alert(data);
            			
                },
                error: function (exception) {
                    alert(JSON.stringify(exception));
                }
            });
	}
</script>
</head>
<body>
<div class="container">
	<div class="row">
		<div class="col-xs-12 col-sm-12">
			<p class="userhead">Portfolio</p>
		</div>
	</div>


	<?php for ($i=0; $i <sizeof($obj5->fundname) ; $i++) {  ?>
		<div class="row">
			<div class="col-xs-4 col-sm-4 col-md-4">
				<p class="text" id="fund<?php echo$i; ?>"><?= Html::encode($obj5->fundname[$i]) ?></p>
				
			</div>
			<div class="col-xs-4 col-sm-4 col-md-4">
				<input type="text" name="amount" class="textboxstyle" id="unit<?php echo$i; ?>" placeholder='Units'>
				
				
			</div>
			<div class="col-xs-4 col-sm-4 col-md-4">
				<button class="btn btn-primary" onclick="onAdd(this.id)" id="<?php echo $i; ?>">ADD</button>
				
			</div>
			
		</div>
		<div class="row">
				<div class="col-xs-12 col-sm-12"><hr></div>
			</div>
	<?php }  ?>

	<div class="row">
		<div class="col-xs-12 col-sm-12">
			<button class="btn btn-success" onclick="onAddAll()">Add All</button>
		</div>
	</div>
</div>
</body>
</html>