<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<style type="text/css">
	.text
	{
		font-size: 20px;
		color: black;
		cursor:pointer;
	}
</style>
<script type="text/javascript">

</script>	
</head>
<body>
<?php use yii\helpers\Html;
	
  ?>
<div class="container">
	<div calss="row">
		<h1>Investor1</h1>
		<div class="col-xs-6 col-sm-4 col-md-2">
			<div>
	
				
					<p1>Here the profile of investor will be shown such as picture, emails, contact numbers etc extracted feom DB</p1>
				
			</div> 
			<div class="row">
				
				
			</div>

		</div>
		<div class="col-xs-6 col-sm-8 col-md-10" id="view2">
				<div class="row">
					<div class="col-xs-6 col-sm-6 col-md-6">
						 
					</div>
					<div class="col-xs-6 col-sm-6 col-md-6">
						
					</div>
					</div>
				</div>
				
			
	</div>
</div>
</body>
</html>