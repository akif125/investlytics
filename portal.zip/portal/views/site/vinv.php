<!DOCTYPE html>
<html>
<head>
	<?php use yii\helpers\Html;
  use yii\helpers\Url;
  
  ?>
	<style type="text/css">
		.userhead
	  	{
	  		font-size: 50px;
	  		font-family: bold;
	  		color: grey;

	  	}
	  	.imagebox
	  	{
	  		border: 1px solid black;
	  		height: 210px;
	  		width: 200px;
	  		margin-left: 470px;
	  	}
	</style>
</head>
<body>
<div class="container">
	<div class="row">
		<div class="col-xs-12 col-sm-12">
			<h1 class="userhead">Profile</h1>
		</div>
	</div>
	<div class="row">
		<div class="col-xs-12 col-sm-12">
			<div class="imagebox">
				<img src="<?= Yii::$app->request->baseUrl ?>/img/img_avatar.png" alt="Avatar" style="width:100%;height: 210px;">
			</div>
		</div>
	</div>
	<div class="row">
		<div class="col-xs-12 col-sm-12">
			<br>
		</div>
	</div>
	<table class="table table-striped">
    <thead>
      <tr>
        
        

      </tr>
    </thead>
    <tbody>
        <tr>
                    
        <td>Name</td>
        <td><?= Html::encode($obj4->name) ?></td>        
        </tr>
        <tr>
                    
        <td>Email</td>
        <td><?= Html::encode($obj4->email) ?></td>        
        </tr>
        <tr>
                    
        <td>CNIC</td>
        <td><?= Html::encode($obj4->cnic) ?></td>        
        </tr>
        <tr>
                    
        <td>Date Of Birth</td>
        <td><?= Html::encode($obj4->dateofbirth) ?></td>        
        </tr>
        
      
      
    </tbody>
  </table>
</div>
</body>
</html>